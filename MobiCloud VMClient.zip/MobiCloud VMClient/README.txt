-----------------------------------
-- Mobicloud VM Client
-----------------------------------

Here are instructions to run this project.

1) Setup eclipse and install the latest JRE.
2) Create new project and add all the files in the src directory.
3) Right-click project>properties and click Build Path. Add external libraries (Smack*.jar and mysql-connector.jar).
4) Run SQL file on localhost.
5) IF you're running on Windows, make sure to edit all the PATHS in the code to fit Windows paths.
		(i.e. /home/saada/Desktop/ ===> C:\\users\\saada\\Desktop\\)

Good luck =)
~Mahmoud Saada
