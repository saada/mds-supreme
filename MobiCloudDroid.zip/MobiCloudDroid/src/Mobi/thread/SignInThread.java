package Mobi.thread;

import java.util.Collection; 

import org.jivesoftware.smack.ConnectionListener;
import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.Roster;
import org.jivesoftware.smack.RosterListener;
import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.filter.MessageTypeFilter;
import org.jivesoftware.smack.filter.PacketFilter;
import org.jivesoftware.smack.filter.PacketTypeFilter;
import org.jivesoftware.smack.packet.IQ;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smack.packet.RosterPacket;
import org.jivesoftware.smack.provider.ProviderManager;
import org.jivesoftware.smackx.filetransfer.FileTransferListener;
import org.jivesoftware.smackx.filetransfer.FileTransferManager;
import org.jivesoftware.smackx.filetransfer.FileTransferRequest;
import org.jivesoftware.smackx.filetransfer.IncomingFileTransfer;
import org.jivesoftware.smackx.provider.VCardProvider;

import Mobi.UI.MobiCloudDroidActivity;
import Mobi.config.MsgDict;
import Mobi.xmpp.XMPPConnectionEntry;



public class SignInThread extends Thread {
	private XMPPConnectionEntry XMPPConnectionEntry_;
	private XMPPConnection XMPPConnection_;
	private String username_;
	private String pw_;
	private Presence.Type presence_;
	private String status_;

	public SignInThread(XMPPConnectionEntry c) {
		XMPPConnectionEntry_ = c;
		XMPPConnection_ = c.getXMPPConnection();
		username_ = c.getEmail();
		pw_ = c.getPw();
		presence_ = c.getPresence();
		status_ = c.getStatus();
	}

	public void run() {
		try {
			XMPPConnection_.connect();
			if (XMPPConnection_.isConnected()) {
				XMPPConnection_.login(username_, pw_, "android");
				if (XMPPConnection_.isAuthenticated()) {
					// Add Roster listener to get the entire roster update after
					// signin
					PacketTypeFilter packetTypeFilter = new PacketTypeFilter(
							RosterPacket.class);
					XMPPConnection_.addPacketListener(new PacketListener() {
						public void processPacket(Packet packet) {
							RosterPacket r = (RosterPacket) packet;
							IQ.Type type = r.getType();
							if (type == IQ.Type.RESULT) {
								MobiCloudDroidActivity.notifyHandler(
										MsgDict.C_ROSTER_RECEIVED,
										new Object[] { XMPPConnectionEntry_ });
								MobiCloudDroidActivity.notifyHandler(MsgDict.LOG,
										r.toXML());
							}
						}
					}, packetTypeFilter);

					// Add Connection Listener for exception handling
					XMPPConnection_
							.addConnectionListener(new ConnectionListener() {

								
								public void connectionClosed() {
//									MobiCloudTVActivity.notifyHandler(
//											MsgDict.S_TOAST_S,
//											"Connection Closed.");
									MobiCloudDroidActivity
											.notifyHandler(
													MsgDict.S_DISCONNECTED,
													new Object[] {
															XMPPConnectionEntry_,
															null });
								}

								
								public void connectionClosedOnError(Exception e) {
//									MobiCloudTVActivity.notifyHandler(
//											MsgDict.S_TOAST_S,
//											"Connection Closed with error.");
									MobiCloudDroidActivity.notifyHandler(
											MsgDict.S_DISCONNECTED,
											new Object[] {
													XMPPConnectionEntry_, e });
								}

							
								public void reconnectingIn(int seconds) {
//									MobiCloudTVActivity.notifyHandler(
//											MsgDict.S_TOAST_S,
//											"Reconnecting in " + seconds
//													+ "sec...");
								}

								
								public void reconnectionFailed(Exception e) {
//									MobiCloudTVActivity.notifyHandler(
//											MsgDict.S_TOAST_S,
//											"Reconnect failed.");
									MobiCloudDroidActivity.notifyHandler(
											MsgDict.S_DISCONNECTED, e);
								}

								
								public void reconnectionSuccessful() {
//									MobiCloudTVActivity.notifyHandler(
//											MsgDict.S_TOAST_S, "Reconnected.");
								}
							});

					// Get roster and set listener
					final Roster roster = XMPPConnection_.getRoster();
					roster.setSubscriptionMode(Roster.SubscriptionMode.accept_all);
					roster.addRosterListener(new RosterListener() {

						
						public void entriesAdded(Collection<String> addresses) {
							MobiCloudDroidActivity.notifyHandler(
									MsgDict.C_ROSTER_ENTRY_ADDED, new Object[] {
											roster, addresses });
						}

					
						public void entriesDeleted(Collection<String> addresses) {
							MobiCloudDroidActivity.notifyHandler(
									MsgDict.C_ROSTER_ENTRY_REMOVED,
									new Object[] { roster, addresses });
						}

					
						public void entriesUpdated(Collection<String> addresses) {
							MobiCloudDroidActivity.notifyHandler(
									MsgDict.C_ROSTER_ENTRY_UPDATED,
									new Object[] { roster, addresses });
						}

					
						public void presenceChanged(Presence presence) {
							MobiCloudDroidActivity.notifyHandler(
									MsgDict.C_PRESENCE_CHANGED, new Object[] {
											XMPPConnectionEntry_, presence });
							MobiCloudDroidActivity.notifyHandler(MsgDict.LOG,
									presence.toXML());
						}
					});

					// Send presence to server
					Presence presence = new Presence(Presence.Type.available);
					presence.setStatus(status_);
					presence.setPriority(10);
					presence.setMode(Presence.Mode.chat);
					XMPPConnection_.sendPacket(presence);

					// Add package listener for message forwarding to
					// MobiCloudTVActivity
					PacketFilter filter = new MessageTypeFilter(
							Message.Type.chat);
					XMPPConnection_.addPacketListener(new PacketListener() {
						public void processPacket(Packet packet) {
							Message message = (Message) packet;
							MobiCloudDroidActivity.notifyHandler(MsgDict.S_CHAT,
									new Object[] { message, XMPPConnection_ });
						}
					}, filter);

					// Add Presence package listener for debug
					// PacketTypeFilter presencePacketTypeFilter = new
					// PacketTypeFilter(
					// Presence.class);
					// XMPPConnection_.addPacketListener(new PacketListener() {
					// public void processPacket(Packet packet) {
					// Presence presence = (Presence) packet;
					// XMPPService.notifyHandler(MsgDict.S_CHAT,
					// presence.toXML());
					// }
					// }, presencePacketTypeFilter);

					// Add IQ listener for vcard
					ProviderManager.getInstance().addIQProvider("vCard",
							"vcard-temp", new VCardProvider()); 

					// Notify the connection is successful
					MobiCloudDroidActivity.notifyHandler(MsgDict.S_AUTENTICATION_SUCEED,
							null);

					// File Transfer
					FileTransferManager manager = new FileTransferManager(XMPPConnection_);
					manager.addFileTransferListener(new FileTransferListener() {
					
						public void fileTransferRequest(
								FileTransferRequest request) {
							IncomingFileTransfer transfer = request.accept();
							MobiCloudDroidActivity.notifyHandler(MsgDict.S_RECEIVE_FILE,
									new Object[] { transfer });
						}
					});
					XMPPConnectionEntry_.setFileTransferManager(manager);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
			MobiCloudDroidActivity.notifyHandler(MsgDict.S_AUTENTICATION_FAILED, null);
			if (XMPPConnection_.isConnected())
				XMPPConnection_.disconnect();
		}
	}
}
