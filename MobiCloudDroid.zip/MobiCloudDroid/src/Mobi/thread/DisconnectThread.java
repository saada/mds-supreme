package Mobi.thread;

import org.jivesoftware.smack.XMPPConnection;

import Mobi.xmpp.XMPPConnectionEntry;



public class DisconnectThread extends Thread {
	private XMPPConnection conn_;

	public DisconnectThread(XMPPConnectionEntry c) {
		conn_ = c.getXMPPConnection();
	}

	public void run() {
		if (conn_.isConnected()) {
			conn_.disconnect();
		}
	}
}
