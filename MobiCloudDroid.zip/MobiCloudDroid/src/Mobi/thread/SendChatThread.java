package Mobi.thread;

import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.packet.Message;

import Mobi.UI.MobiCloudDroidActivity;
import Mobi.config.MsgDict;



public class SendChatThread extends Thread {
	private Message message_;
	private XMPPConnection conn_;

	public SendChatThread(XMPPConnection c, Message msg) {
		message_ = msg;
		conn_ = c;
	}

	public void run() {
		if (conn_.isAuthenticated()) {
			conn_.sendPacket(message_);
		} else {
			MobiCloudDroidActivity.notifyHandler(MsgDict.S_TOAST_S,
					"You are not authenticated.");
		}
	}
}
