package Mobi.xmpp;

public class Msg {
	public int type;
	private String[] data;
	public int count;

	public String getData(int index) {
		index++;
		try {
			return data[index];
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
	}

	public Msg(String s) {
		String[] msgs = s.substring(3).split("%@!");
		try {
			type = Integer.parseInt(msgs[0]);
			data = msgs;
			count = msgs.length - 1;
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static String msgString(String[] msgs) {
		String result = "";
		for (String s : msgs) {
			result += ("%@!" + s);
		}
		return result;
	}

	public String toString() {
		String result = "";
		for (String s : data) {
			result += ("%@!" + s);
		}
		return result;
	}
}
