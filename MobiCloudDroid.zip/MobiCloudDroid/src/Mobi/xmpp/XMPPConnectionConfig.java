package Mobi.xmpp;

import org.jivesoftware.smack.ConnectionConfiguration;

public class XMPPConnectionConfig {
	public static ConnectionConfiguration getXMPPConnectionConfig(int settingId) {
		ConnectionConfiguration config = null;
		switch (settingId) {
		case 0:
			config = new ConnectionConfiguration("talk.google.com", 5222,
					"gmail.com");
			config.setCompressionEnabled(false);
			config.setSASLAuthenticationEnabled(false);
			break;
		case 1:
			config = new ConnectionConfiguration("jabber.org", 5222);
			config.setCompressionEnabled(false);
			config.setSASLAuthenticationEnabled(false);
			break;
		case 2:
			//should stop here
			//config = new ConnectionConfiguration("10.141.168.22", 5222);
			config = new ConnectionConfiguration("10.5.18.104", 5222);
			config.setCompressionEnabled(false);
			config.setSASLAuthenticationEnabled(false);
			break;
		case 3:
			config = new ConnectionConfiguration("10.141.162.107", 5222);
			config.setCompressionEnabled(false);
			config.setSASLAuthenticationEnabled(false);
			break;
		}
		return config;
	}
}
