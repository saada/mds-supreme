package Mobi.xmpp;

import java.util.ArrayList;
import java.util.Iterator;

public class FullRoster {
	private ArrayList<UserGroup> groupList_;

	public FullRoster() {
		groupList_ = new ArrayList<UserGroup>();
		addGroup("Online");
	}

	public UserGroup addGroup(String groupName) {
		UserGroup grp;
		synchronized (groupList_) {
			grp = new UserGroup(groupName);
			groupList_.add(grp);
		}
		return grp;
	}

	public void addUser(String groupName, User user) {
		UserGroup grp = getGroup(groupName);
		if (grp == null) {
			grp = addGroup(groupName);
		}
		synchronized (groupList_) {
			grp.addUser(user);
			user.setGroup(grp);
		}
	}

	public UserGroup getGroup(String groupName) {
		synchronized (groupList_) {
			Iterator<UserGroup> i = groupList_.iterator();
			while (i.hasNext()) {
				UserGroup grp = i.next();
				if (grp.name.equals(groupName)) {
					return grp;
				}
			}
		}
		return null;
	}

	public UserGroup getGroup(int index) {
		synchronized (groupList_) {
			try {
				UserGroup grp = groupList_.get(index);
				return grp;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return null;
	}

	public void addUser(User user, String groupName) {
		if (user.getGroup() != null) {
			user.getGroup().removeUser(user);
		}
		addUser(groupName, user);
	}

	public int size() {
		synchronized (groupList_) {
			return groupList_.size();
		}
	}
}
