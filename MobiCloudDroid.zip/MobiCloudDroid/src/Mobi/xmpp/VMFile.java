package Mobi.xmpp;

import org.jivesoftware.smack.packet.Presence;

import Mobi.tree.Node;

public class VMFile {
	private XMPPConnectionEntry ownerConnEntry_;
	private String accountId;
	private String fileName;
	private String fileOwner;
	private String path;
	private int type;
	
	public boolean isIsselected() {
		return isselected;
	}
	public void setIsselected(boolean isselected) {
		this.isselected = isselected;
	}
	public VMFile(String fileName, int type, boolean isselected,
			String lastModifyTime ) {
		super();
		this.fileName = fileName;
		this.type = type;
		this.isselected = isselected;
		this.lastModifyTime = lastModifyTime;
		
	}
	private boolean isselected;
	
	
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileOwner() {
		return fileOwner;
	}
	public void setFileOwner(String fileOwner) {
		this.fileOwner = fileOwner;
	}
	public String getLastModifyTime() {
		return lastModifyTime;
	}
	public void setLastModifyTime(String lastModifyTime) {
		this.lastModifyTime = lastModifyTime;
	}
	private String lastModifyTime;
	private String jid;
	private String status;
	private Presence.Mode mode;
	private boolean isOnline;
	private byte[] avatar;
	private VMFileGroup group;
	
	public String getFileName() {
		return fileName;
	}
	public String getAccountId() {
		return accountId;
	}
	public void setAccountId(String accountId) {
		this.accountId = accountId;
	}
	public VMFileGroup getGroup() {
		return group;
	}
	public void setGroup(VMFileGroup group) {
		this.group = group;
	}
	public String getPath() {
		return path;
	}
	public void setPath(String path) {
		this.path = path;
	}

}
