package Mobi.xmpp;

import java.util.Enumeration;
import java.util.Hashtable;

import org.jivesoftware.smack.ConnectionConfiguration;
import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smack.provider.PrivacyProvider;
import org.jivesoftware.smack.provider.ProviderManager;
import org.jivesoftware.smackx.GroupChatInvitation;
import org.jivesoftware.smackx.PrivateDataManager;
import org.jivesoftware.smackx.filetransfer.FileTransferManager;
import org.jivesoftware.smackx.packet.ChatStateExtension;
import org.jivesoftware.smackx.packet.LastActivity;
import org.jivesoftware.smackx.packet.OfflineMessageInfo;
import org.jivesoftware.smackx.packet.OfflineMessageRequest;
import org.jivesoftware.smackx.packet.SharedGroupsInfo;
import org.jivesoftware.smackx.provider.AdHocCommandDataProvider;
import org.jivesoftware.smackx.provider.BytestreamsProvider;
import org.jivesoftware.smackx.provider.DataFormProvider;
import org.jivesoftware.smackx.provider.DelayInformationProvider;
import org.jivesoftware.smackx.provider.DiscoverInfoProvider;
import org.jivesoftware.smackx.provider.DiscoverItemsProvider;
import org.jivesoftware.smackx.provider.IBBProviders;
import org.jivesoftware.smackx.provider.MUCAdminProvider;
import org.jivesoftware.smackx.provider.MUCOwnerProvider;
import org.jivesoftware.smackx.provider.MUCUserProvider;
import org.jivesoftware.smackx.provider.MessageEventProvider;
import org.jivesoftware.smackx.provider.MultipleAddressesProvider;
import org.jivesoftware.smackx.provider.RosterExchangeProvider;
import org.jivesoftware.smackx.provider.StreamInitiationProvider;
import org.jivesoftware.smackx.provider.VCardProvider;
import org.jivesoftware.smackx.provider.XHTMLExtensionProvider;
import org.jivesoftware.smackx.search.UserSearch;

import Mobi.thread.DisconnectThread;
import Mobi.thread.SignInThread;
import android.util.Log;


public class XMPPConnectionEntry {
	// =================================================================
	// Fields
	// =================================================================
	private String email_;
	private String pw_;
	private int id_;
	private boolean signIn_;
	private int settingId_;
	private Presence.Type presence_;
	private String status_;
	private ConnectionConfiguration XMPPConfig_;
	private XMPPConnection XMPPConnection_;
	private FileTransferManager fileTransferManager_;
	private Hashtable<String, User> userList_;

	// =================================================================
	// Functions
	// =================================================================
	/**
	 * Create an XMPP connection entry
	 * 
	 * @param id
	 * @param email
	 * @param pw
	 * @param signIn
	 * @param settingId
	 */
	public XMPPConnectionEntry(int id, String email, String pw, boolean signIn,
			int settingId, int presence, String status) {
		email_ = email;
		pw_ = pw;
		signIn_ = signIn;
		settingId_ = settingId;
		id_ = id;
		presence_ = (presence == 1) ? Presence.Type.available
				: Presence.Type.unavailable;
		status_ = status;
		XMPPConfig_ = XMPPConnectionConfig.getXMPPConnectionConfig(settingId_);
		// XMPPConnection.DEBUG_ENABLED = true;
		fileTransferManager_ = null;
		configure(ProviderManager.getInstance());
		XMPPConnection_ = new XMPPConnection(XMPPConfig_);
		userList_ = new Hashtable<String, User>();
	}

	public void configure(ProviderManager pm) {
		// Private Data Storage
		pm.addIQProvider("query", "jabber:iq:private",
				new PrivateDataManager.PrivateDataIQProvider());

		// Time
		try {
			pm.addIQProvider("query", "jabber:iq:time",
					Class.forName("org.jivesoftware.smackx.packet.Time"));
		} catch (ClassNotFoundException e) {
			Log.w("TestClient",
					"Can't load class for org.jivesoftware.smackx.packet.Time");
		}

		// Roster Exchange
		pm.addExtensionProvider("x", "jabber:x:roster",
				new RosterExchangeProvider());

		// Message Events
		pm.addExtensionProvider("x", "jabber:x:event",
				new MessageEventProvider());

		// Chat State
		pm.addExtensionProvider("active",
				"http://jabber.org/protocol/chatstates",
				new ChatStateExtension.Provider());

		pm.addExtensionProvider("composing",
				"http://jabber.org/protocol/chatstates",
				new ChatStateExtension.Provider());

		pm.addExtensionProvider("paused",
				"http://jabber.org/protocol/chatstates",
				new ChatStateExtension.Provider());

		pm.addExtensionProvider("inactive",
				"http://jabber.org/protocol/chatstates",
				new ChatStateExtension.Provider());

		pm.addExtensionProvider("gone",
				"http://jabber.org/protocol/chatstates",
				new ChatStateExtension.Provider());

		// XHTML
		pm.addExtensionProvider("html", "http://jabber.org/protocol/xhtml-im",
				new XHTMLExtensionProvider());

		// Group Chat Invitations
		pm.addExtensionProvider("x", "jabber:x:conference",
				new GroupChatInvitation.Provider());

		// Service Discovery # Items
		pm.addIQProvider("query", "http://jabber.org/protocol/disco#items",
				new DiscoverItemsProvider());

		// Service Discovery # Info
		pm.addIQProvider("query", "http://jabber.org/protocol/disco#info",
				new DiscoverInfoProvider());

		// Data Forms
		pm.addExtensionProvider("x", "jabber:x:data", new DataFormProvider());

		// MUC User
		pm.addExtensionProvider("x", "http://jabber.org/protocol/muc#user",
				new MUCUserProvider());

		// MUC Admin
		pm.addIQProvider("query", "http://jabber.org/protocol/muc#admin",
				new MUCAdminProvider());

		// MUC Owner
		pm.addIQProvider("query", "http://jabber.org/protocol/muc#owner",
				new MUCOwnerProvider());

		// Delayed Delivery
		pm.addExtensionProvider("x", "jabber:x:delay",
				new DelayInformationProvider());

		// Version
		try {
			pm.addIQProvider("query", "jabber:iq:version",
					Class.forName("org.jivesoftware.smackx.packet.Version"));
		} catch (ClassNotFoundException e) {
			// Not sure what's happening here.
		}

		// VCard
		pm.addIQProvider("vCard", "vcard-temp", new VCardProvider());

		// Offline Message Requests
		pm.addIQProvider("offline", "http://jabber.org/protocol/offline",
				new OfflineMessageRequest.Provider());

		// Offline Message Indicator
		pm.addExtensionProvider("offline",
				"http://jabber.org/protocol/offline",
				new OfflineMessageInfo.Provider());

		// Last Activity
		pm.addIQProvider("query", "jabber:iq:last", new LastActivity.Provider());

		// User Search
		pm.addIQProvider("query", "jabber:iq:search", new UserSearch.Provider());

		// SharedGroupsInfo
		pm.addIQProvider("sharedgroup",
				"http://www.jivesoftware.org/protocol/sharedgroup",
				new SharedGroupsInfo.Provider());

		// JEP-33: Extended Stanza Addressing
		pm.addExtensionProvider("addresses",
				"http://jabber.org/protocol/address",
				new MultipleAddressesProvider());

		// FileTransfer
		pm.addIQProvider("si", "http://jabber.org/protocol/si",
				new StreamInitiationProvider());

		pm.addIQProvider("query", "http://jabber.org/protocol/bytestreams",
				new BytestreamsProvider());

		pm.addIQProvider("open", "http://jabber.org/protocol/ibb",
				new IBBProviders.Open());

		pm.addIQProvider("close", "http://jabber.org/protocol/ibb",
				new IBBProviders.Close());

		pm.addExtensionProvider("data", "http://jabber.org/protocol/ibb",
				new IBBProviders.Data());

		// Privacy
		pm.addIQProvider("query", "jabber:iq:privacy", new PrivacyProvider());

		pm.addIQProvider("command", "http://jabber.org/protocol/commands",
				new AdHocCommandDataProvider());
		pm.addExtensionProvider("malformed-action",
				"http://jabber.org/protocol/commands",
				new AdHocCommandDataProvider.MalformedActionError());
		pm.addExtensionProvider("bad-locale",
				"http://jabber.org/protocol/commands",
				new AdHocCommandDataProvider.BadLocaleError());
		pm.addExtensionProvider("bad-payload",
				"http://jabber.org/protocol/commands",
				new AdHocCommandDataProvider.BadPayloadError());
		pm.addExtensionProvider("bad-sessionid",
				"http://jabber.org/protocol/commands",
				new AdHocCommandDataProvider.BadSessionIDError());
		pm.addExtensionProvider("session-expired",
				"http://jabber.org/protocol/commands",
				new AdHocCommandDataProvider.SessionExpiredError());
	}

	public void startConnect() {
		new SignInThread(this).start();
	}

	public void startDisconnect() {
		new DisconnectThread(this).start();
	}

	public void addUser(User user) {
		synchronized (userList_) {
			userList_.put(user.getJid(), user);
		}
	}

	public User getUser(String jid) {
		synchronized (userList_) {
			return userList_.get(jid);
		}
	}

	public void removeAllUser() {
		synchronized (userList_) {
			Enumeration<User> i = userList_.elements();
			while (i.hasMoreElements()) {
				User user = i.nextElement();
				user.getGroup().removeUser(user);
			}
			userList_.clear();
		}
	}

	// =================================================================
	// Getters and Setters
	// =================================================================
	public void setFileTransferManager(FileTransferManager m) {
		fileTransferManager_ = m;
	}

	public FileTransferManager getFileTransferManager() {
		return fileTransferManager_;
	}

	public void setEmail(String email) {
		this.email_ = email;
	}

	public String getEmail() {
		return email_;
	}

	public void setPw(String pw) {
		this.pw_ = pw;
	}

	public String getPw() {
		return pw_;
	}

	public void setId(int id) {
		this.id_ = id;
	}

	public int getId() {
		return id_;
	}

	public void setSignIn(boolean signIn) {
		this.signIn_ = signIn;
	}

	public boolean isSignIn() {
		return signIn_;
	}

	public void setXMPPConnection(XMPPConnection xMPPConnection) {
		XMPPConnection_ = xMPPConnection;
	}

	public XMPPConnection getXMPPConnection() {
		return XMPPConnection_;
	}

	public int getSettingId() {
		return settingId_;
	}

	public void setSettingId(int settingId) {
		this.settingId_ = settingId;
	}

	public ConnectionConfiguration getXMPPConfig() {
		return XMPPConfig_;
	}

	public void setXMPPConfig(ConnectionConfiguration xMPPConfig) {
		XMPPConfig_ = xMPPConfig;
	}

	public void setPresence(Presence.Type presence_) {
		this.presence_ = presence_;
	}

	public Presence.Type getPresence() {
		return presence_;
	}

	public void setStatus(String status_) {
		this.status_ = status_;
	}

	public String getStatus() {
		return status_;
	}

}
