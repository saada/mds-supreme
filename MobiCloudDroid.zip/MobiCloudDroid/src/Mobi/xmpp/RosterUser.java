package Mobi.xmpp;

import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smackx.packet.VCard;

public class RosterUser {
	private String name_;
	private String jid_;
	private Presence.Mode mode_;
	private String status_;

	private void temp() {
		VCard card = new VCard();
		try {
			card.load(null, "user@fqdn");
		} catch (XMPPException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		// BitmapFactory.decodeByteArray(data, offset, length)
	}

	public void setName(String name_) {
		this.name_ = name_;
	}

	public String getName() {
		return name_;
	}

	public void setJid(String jid_) {
		this.jid_ = jid_;
	}

	public String getJid() {
		return jid_;
	}

	public void setMode(Presence.Mode mode_) {
		this.mode_ = mode_;
	}

	public Presence.Mode getMode() {
		return mode_;
	}

	public void setStatus(String status_) {
		this.status_ = status_;
	}

	public String getStatus() {
		return status_;
	}
}
