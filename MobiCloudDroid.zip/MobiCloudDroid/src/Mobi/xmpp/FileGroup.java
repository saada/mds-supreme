package Mobi.xmpp;

public class FileGroup {

}
