package Mobi.xmpp;

public class Group {
	
	private String groupName;	
	private boolean isselected;
	public Group(String groupName, boolean selected) {
		super();
		this.setGroupName(groupName);
		this.isselected = selected;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
}
