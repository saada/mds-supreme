package Mobi.xmpp;

public class ToDo {
	public ToDo(int w, Object o) {
		what = w;
		obj = o;
	}

	public int what;
	public Object obj;
}
