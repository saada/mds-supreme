package Mobi.xmpp;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

public class VMFileGroup {
	public String name;
	private LinkedList<VMFile> fileList_;

	public VMFileGroup(String n) {
		name = n;
		fileList_ = new LinkedList<VMFile>();
	}

	public void addFile(VMFile file) {
		synchronized (fileList_) {
			fileList_.add(file);
			sort();
		}
	}

	public boolean removeFile(VMFile file) {
		synchronized (fileList_) {
			if (fileList_.remove(file)) {
				sort();
				return true;
			} else {
				return false;
			}
		}
	}

	public void removeFile(String jid, int accountId) {

	}

	public int size() {
		synchronized (fileList_) {
			return fileList_.size();
		}
	}

	public VMFile getFile(int index) {
		synchronized (fileList_) {
			try {
				return fileList_.get(index);
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
	}

	public void sort() {
		Collections.sort(fileList_, new Comparator<VMFile>() {

			public int compare(VMFile a, VMFile b) {
				try {
					return a.getFileName().toLowerCase()
							.compareTo(b.getFileName().toLowerCase());
				} catch (Exception e) {
					try {
						return a.getAccountId().toLowerCase()
								.compareTo(b.getAccountId().toLowerCase());
					} catch (Exception e1) {
						return 0;
					}
				}
			}
		});
	}
}
