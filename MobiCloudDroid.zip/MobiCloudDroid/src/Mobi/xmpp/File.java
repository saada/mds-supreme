package Mobi.xmpp;

import org.jivesoftware.smack.packet.Presence;

public class File {
	private XMPPConnectionEntry ownerConnEntry_;
	private int accountId;
	private String fileName;
	private String fileOwner;
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public String getFileOwner() {
		return fileOwner;
	}
	public void setFileOwner(String fileOwner) {
		this.fileOwner = fileOwner;
	}
	public String getLastModifyTime() {
		return lastModifyTime;
	}
	public void setLastModifyTime(String lastModifyTime) {
		this.lastModifyTime = lastModifyTime;
	}
	private String lastModifyTime;
	private String jid;
	private String status;
	private Presence.Mode mode;
	private boolean isOnline;
	private byte[] avatar;
	private FileGroup group;
}
