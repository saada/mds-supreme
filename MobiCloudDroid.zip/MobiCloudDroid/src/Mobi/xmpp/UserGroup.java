package Mobi.xmpp;

import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedList;

public class UserGroup {
	public String name;
	private LinkedList<User> userList_;

	public UserGroup(String n) {
		name = n;
		userList_ = new LinkedList<User>();
	}

	public void addUser(User user) {
		synchronized (userList_) {
			userList_.add(user);
			sort();
		}
	}

	public boolean removeUser(User user) {
		synchronized (userList_) {
			if (userList_.remove(user)) {
				sort();
				return true;
			} else {
				return false;
			}
		}
	}

	public void removeUser(String jid, int accountId) {

	}

	public int size() {
		synchronized (userList_) {
			return userList_.size();
		}
	}

	public User getUser(int index) {
		synchronized (userList_) {
			try {
				return userList_.get(index);
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
	}

	public void sort() {
		Collections.sort(userList_, new Comparator<User>() {

			public int compare(User a, User b) {
				try {
					return a.getDispName().toLowerCase()
							.compareTo(b.getDispName().toLowerCase());
				} catch (Exception e) {
					try {
						return a.getJid().toLowerCase()
								.compareTo(b.getJid().toLowerCase());
					} catch (Exception e1) {
						return 0;
					}
				}
			}
		});
	}
}
