package Mobi.xmpp;

import java.util.Iterator;
import java.util.LinkedList;

import org.jivesoftware.smack.Roster;
import org.jivesoftware.smack.RosterEntry;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smack.packet.Presence.Mode;

import android.database.Cursor;
import android.util.Log;

public class XMPPConnectionManager {
	// =================================================================
	// Fields
	// =================================================================
	// ConnectionEntry for each account of user's
	private LinkedList<XMPPConnectionEntry> connEntries_;

	// =================================================================
	// Constructor
	// =================================================================
	public XMPPConnectionManager() {
		connEntries_ = new LinkedList<XMPPConnectionEntry>();

		XMPPService.DB_ADAPTER.open();
		Cursor accountCursor = XMPPService.DB_ADAPTER.getAllAccount();

		if (accountCursor.moveToFirst()) {
			do {
				// Create an entry for each account stored in db
				int id = accountCursor.getInt(accountCursor
						.getColumnIndex("id"));
				String login = accountCursor.getString(accountCursor
						.getColumnIndex("login"));
				String pw = accountCursor.getString(accountCursor
						.getColumnIndex("pw"));
				boolean signin = (accountCursor.getInt(accountCursor
						.getColumnIndex("signin")) == 1) ? true : false;
				int settingId = accountCursor.getInt(accountCursor
						.getColumnIndex("setting_id"));
				int presence = accountCursor.getInt(accountCursor
						.getColumnIndex("presence"));
				String status = accountCursor.getString(accountCursor
						.getColumnIndex("status"));
				XMPPConnectionEntry connEntry = new XMPPConnectionEntry(id,
						login, pw, signin, settingId, presence, status);

				// If the account is set to auto-signin, do it
				if (signin) {
					// connEntry.startConnect();
				}

				// Store the account in memory
				synchronized (connEntries_) {
					connEntries_.add(connEntry);
				}
			} while (accountCursor.moveToNext());
		} else {
			XMPPService.DB_ADAPTER.insert("larrxu", "cindere1!A", true, 0, 1,
					"Android");
			XMPPService.DB_ADAPTER.insert("larrxu.jabber", "xfkwsn0w", true, 0,
					1, "Android");
			XMPPService.DB_ADAPTER.insert("mobicloud1", "mobicloud", true, 2,
					1, "Android");
			XMPPService.DB_ADAPTER.insert("mobicloud2", "mobicloud", true, 2,
					1, "Android");
			XMPPService.DB_ADAPTER.insert("mobicloud1", "mobicloud", true, 3,
					1, "Android");
			XMPPService.DB_ADAPTER.insert("mobicloud2", "mobicloud", true, 3,
					1, "Android");
		}
		accountCursor.close();
		XMPPService.DB_ADAPTER.close();
	}

	// =================================================================
	// XMPPConnection Related Operation
	// =================================================================
	public boolean isEmpty() {
		synchronized (connEntries_) {
			return connEntries_.isEmpty();
		}
	}

	public int size() {
		synchronized (connEntries_) {
			return connEntries_.size();
		}
	}

	public XMPPConnectionEntry get(int pos) {
		synchronized (connEntries_) {
			try {
				return connEntries_.get(pos);
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
	}

	public void remove(XMPPConnectionEntry connEntry) {
		synchronized (connEntries_) {
			connEntry.startDisconnect();
			connEntries_.remove(connEntry);
			XMPPService.DB_ADAPTER.open();
			XMPPService.DB_ADAPTER.deleteAccount(connEntry.getId());
			XMPPService.DB_ADAPTER.close();
		}
	}

	// public FullRoster getCurrentFullRoster() {
	// FullRoster fullRoster = new FullRoster();
	// synchronized (connEntries_) {
	// Iterator<XMPPConnectionEntry> n = connEntries_.iterator();
	// while (n.hasNext()) {
	// XMPPConnectionEntry connEntry = n.next();
	// addUserToFullRoster(fullRoster, connEntry);
	// }
	// }
	// return fullRoster;
	// }

	public void addUserToFullRoster(FullRoster fullRoster,
			XMPPConnectionEntry connEntry) {
		if (!connEntry.getXMPPConnection().isAuthenticated())
			return;
		Roster roster = connEntry.getXMPPConnection().getRoster();
		Iterator<RosterEntry> i = roster.getEntries().iterator();
		while (i.hasNext()) {
			// Create user object
			RosterEntry rosterEntry = i.next();
			User user = connEntry.getUser(rosterEntry.getUser());
			if (user == null) {
				user = new User();
				if (rosterEntry.getName() == null
						|| rosterEntry.getName().equals("")) {
					user.setDispName(rosterEntry.getUser().split("@")[0]);
				} else {
					user.setDispName(rosterEntry.getName());
				}
				user.setAccountId(connEntry.getId());
				user.setJid(rosterEntry.getUser());
				user.setOwnerConnEntry(connEntry);
				connEntry.addUser(user);
			}
			Presence presence = roster.getPresence(user.getJid());
			user.setOnline(presence.isAvailable());
			user.setMode(presence.getMode());
			user.setStatus(presence.getStatus());

			// Put into user group
			// synchronized (fullRoster) {
			// if (presence.getType() != Presence.Type.unavailable) {
			// fullRoster.addUser(user, "Online");
			// } else {
			// fullRoster.addUser(user, "Offline");
			// }
			// }

			synchronized (XMPPService.FULL_ROSTER) {
				if (presence.getType() != Presence.Type.unavailable) {
					XMPPService.FULL_ROSTER.addUser(user, "Online");
				} else {
					XMPPService.FULL_ROSTER.addUser(user, "Offline");
				}
			}
		}
	}

	// =================================================================
	// Event Handler
	// =================================================================
	public void onDestroy() {
		synchronized (connEntries_) {
			Iterator<XMPPConnectionEntry> i = connEntries_.iterator();
			while (i.hasNext()) {
				XMPPConnectionEntry connEntry = i.next();
				connEntry.startDisconnect();
			}
			connEntries_.clear();
		}
	}

	public void onLowMemory() {

	}
}
