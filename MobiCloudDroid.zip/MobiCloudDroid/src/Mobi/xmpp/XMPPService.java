package Mobi.xmpp;

import Mobi.UI.DatabaseAdapter;
import android.app.Service;
import android.content.Intent;
import android.content.res.Configuration;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import android.widget.Toast;


public class XMPPService extends Service {
	// =================================================================
	// Fields
	// =================================================================
	// Link to MainActivity
	private static Handler handler_;
	// Indicates if service is started
	private boolean isServiceStarted_;
	// XMPPConnectionManager
	public static XMPPConnectionManager CONNECTION_MANAGER;
	// DB Adapter
	public static DatabaseAdapter DB_ADAPTER;
	// Full Roster
	public static FullRoster FULL_ROSTER = new FullRoster();

	// =================================================================
	// Event Handlers
	// =================================================================
	@Override
	public void onCreate() {
		isServiceStarted_ = false;
		DB_ADAPTER = new DatabaseAdapter(this);
		CONNECTION_MANAGER = new XMPPConnectionManager();
	}

	@Override
	public int onStartCommand(Intent intent, int flags, int startId) {
		if (!isServiceStarted_) {
			isServiceStarted_ = true;
			// Toast.makeText(this, "Service.onStartCommand",
			// Toast.LENGTH_SHORT)
			// .show();
		}
		return Service.START_STICKY;
	}

	@Override
	public void onConfigurationChanged(Configuration newConfig) {
		super.onConfigurationChanged(newConfig);
		// Toast.makeText(this, "Service.onConfigurationChanged",
		// Toast.LENGTH_SHORT).show();
	}

	@Override
	public void onLowMemory() {
		super.onLowMemory();
		CONNECTION_MANAGER.onLowMemory();
		Toast.makeText(this, "Service.onLowMemory", Toast.LENGTH_SHORT).show();
	}

	@Override
	public void onDestroy() {
		isServiceStarted_ = false;
		DB_ADAPTER.close();
		CONNECTION_MANAGER.onDestroy();
		Toast.makeText(this, "Service.onDestroy", Toast.LENGTH_SHORT).show();
	}

	@Override
	public IBinder onBind(Intent intent) {
		return binder_;
	}

	// // =================================================================
	// // Called when bound with MainActivity
	// // =================================================================
	// public void setMainActivity(MainActivity mainActivity) {
	// handler_ = mainActivity.getHandler();
	// }

	// // =================================================================
	// // Handler
	// // =================================================================
	// public static void notifyHandler(int what, Object obj) {
	// if (handler_ != null) {
	// android.os.Message message = new android.os.Message();
	// message.what = what;
	// message.obj = obj;
	// handler_.sendMessage(message);
	// }
	// }

	// =================================================================
	// This is the object that receives interactions from clients. See
	// RemoteService for a more complete example.
	// =================================================================
	private final IBinder binder_ = new LocalBinder();

	public class LocalBinder extends Binder {
		public XMPPService getService() {
			return XMPPService.this;
		}
	}

	// =================================================================
	// Getters and Setters
	// =================================================================
	public XMPPConnectionManager getXMPPConnectionManager() {
		return CONNECTION_MANAGER;
	}
}
