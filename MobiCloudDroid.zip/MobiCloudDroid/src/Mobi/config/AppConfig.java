package Mobi.config;

public class AppConfig {
	// =========================================================
	// Network Related
	// =========================================================
	public final static String SERVER_URL = "cloudroid.servegame.com";

	// =========================================================
	// Activity Related
	// =========================================================
	public final static int STAGE_LOGIN = 0x01;
	public final static int STAGE_CONTACTS = 0x02;
	public final static int STAGE_MYFILES = 0x03;
	public final static int STAGE_SETTINGS = 0x04;
	
	public final static int DIALOG_SHARE = 0x01;
	public final static int DIALOG_CHAT = 0x02;

	public final static String APP_NAME = "MobiTV";

	public final static int RANK_BY_ONLINE_STATUS = 0x01;
	public final static int RANK_BY_ACCOUNT = 0x02;
	
    public static final int GROUP_LIST = 0x00;
    public static final int FRIEND_LIST = 0x01;
	public static final int FILE_LIST = 0x02;
	public static final int DIR_LIST = 0x03;

}
