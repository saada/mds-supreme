package Mobi.util;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

import log.Log;


public class CS_FileTransfer {
	String DomainName;
	int serverPort;
	String filename;
	Socket sock;
	ServerSocket listenSocket;
	
	public CS_FileTransfer(String domain, int port, String file) throws IOException
	{
		DomainName = domain;
		serverPort = port;
		filename = file;
		listenSocket = new ServerSocket(serverPort);
		
	}
	public void invoke(boolean flag) throws IOException
	{
		Log.i("DomainName:"+DomainName+"  ServerPort:"+serverPort);
		sock = new Socket(DomainName,serverPort);
		Invoke_Connnection invoke = new Invoke_Connnection(DomainName,filename,sock,flag);
		invoke.start();
		Log.i("finished");
	}
	public void close() throws IOException{
		sock.close();
		listenSocket.close();
	}
}
