package Mobi.util;

import java.util.ArrayList;
import java.util.List;

import android.util.Log;

import Mobi.config.MsgDict;

public class MsgProtocal {
    public static String createRequestDirectoryMessage(String jid){
    	return "<MSG><requests><view type=\""+MsgDict.FILELIST_REQUEST+"\" jid=\""+jid+"\" ></view></requests></MSG>";
    }

	public static String createPermissonChangeMessage(ArrayList<String> entity, ArrayList<String> jids, int permission) {
		String str = "<MSG><requests>";
		String entityId;
		String jid;
		for(int i=0; i<entity.size(); i++)
		{
			entityId = entity.get(i);
			for(int j=0; j<jids.size(); j++)
			{
				jid = jids.get(j);
				str+="<modify type = \""+MsgDict.USERPERMISSION_REQUEST+"\"><user_permission e_id=\""+entityId
						+"\" jid=\""+jid
						+"\" permission=\""+permission
						+"\"></user_permission></modify>";
			}
			
		}
		 str+="</requests></MSG>";
		 return str;
	}
	//DELETE
	public static String createRequestDelete(ArrayList<String> entity)
	{ 
		String str = "<MSG><requests>";
		String entityId;
		for(int i=0;i<entity.size();i++){
			entityId = entity.get(i);
			str += "<modify type = \""+MsgDict.DELETE_REQUEST+"\">"
					+"<delete e_id=\""+ entityId
					+"\"></delete></modify>";
		}
		str+="</requests></MSG>";
		return str;                  }

	public static String createRequestMove(String e_id, String path) {
		String str = "<MSG><requests>";			
			str += "<modify type = \""+MsgDict.MOVE_REQUEST+"\">"
			+"<move e_id=\""+e_id
			+"\" newpath=\""+ path 
			+"\"></move>" +
			"</modify></requests></MSG>";  	
		
		return str;		
	}

	public static String createPermissonUploading(String jid, String des, List<String> file_list) {
				
			String str = "<MSG><requests>";
			for(int i=0;i<file_list.size();i++){
				String[] name =file_list.get(i).split("/");				
				str += "<upload type=\""+MsgDict.UPLOAD_REQUEST+"\" jid=\""
						+jid +"\" destination=\""+ des
						+ "\" filename=\""+ name[name.length-1]  +"\"></upload>";
			}			
			str +="</requests></MSG>";		
		return str;
	}

	public static String createPermissonDownloading(String jid, String des,
			List<String> file_list, List<String> file_name) {
		
		String str = "<MSG><requests>";
		
		for(int i=0;i<file_list.size();i++){
			String[] name =file_list.get(i).split("/");
			
			str += "<download type=\""+MsgDict.DOWNLOAD_REQUEST+"\" jid=\""
					+jid +"\" destination=\""+ file_list.get(i)
					+ "\" filename=\""+ file_name.get(i) +"\"></download>";
		}			
		str +="</requests></MSG>";		
	return str;
	}
	public static String createPermissonDownloadingFriend(String jid, String des,
			List<String> file_list, List<String> file_name) {
		String str = "<MSG><requests>";
		for(int i=0;i<file_list.size();i++){
			String[] name =file_list.get(i).split("/");				
			str += "<download type=\""+MsgDict.DOWNLOAD_REQUEST_FRIEND+"\" jid=\""
					+jid +"\" destination=\""+ file_list.get(i)
					+ "\" filename=\""+ file_name.get(i)  +"\"></download>";
		}			
		str +="</requests></MSG>";		
	return str;
	}
	
    
}
