package Mobi.util;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.net.Socket;
import java.nio.MappedByteBuffer;
import java.nio.channels.FileChannel;
import java.nio.channels.FileChannel.MapMode;


public class TabletTCP{
	int serverPort=6880;
	String file;
	String domain;
	DataInputStream input;
    DataOutputStream output;
    Socket clientSocket;
	public TabletTCP (String filename, String domainname){
		file= filename;
		domain = domainname;
	}
	public void run(){
	    try{
	    	clientSocket = new Socket(domain, serverPort);
			input = new DataInputStream( clientSocket.getInputStream());
			output =new DataOutputStream( clientSocket.getOutputStream());			
			File f = new File(file);
			FileInputStream fin = null;
			FileChannel ch = null;    
			fin = new FileInputStream(f);
			ch = fin.getChannel();
			int size = (int) ch.size();
			MappedByteBuffer buf = ch.map(MapMode.READ_ONLY, 0, size);
			byte[] bytes = new byte[size];
			buf.get(bytes);
			output.writeInt(bytes.length);
			output.write(bytes);
			output.flush();
			try{
				int leng = input.readInt();
				byte[] fin2 = new byte[leng];
				input.readFully(fin2, 0, leng);
				String info = new String(fin2);
				System.out.println(info);
			}
			catch(Exception e)
			{
				e.printStackTrace();
				System.out.println("Unable to indentify the successful signal");
			}
	    }
	    catch (IOException e) {
				e.printStackTrace();
	    }
	    finally{

	    }
	}
}
