package Mobi.tree;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import log.Log;

import Mobi.UI.Global;
import Mobi.UI.MobiCloudDroidActivity;
import Mobi.UI.R;
import Mobi.UI.R.id;
import Mobi.config.AppConfig;
import Mobi.config.MsgDict;
import Mobi.xmpp.Entity;
import Mobi.xmpp.Group;
import Mobi.xmpp.User;
import Mobi.xmpp.VMFile;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.MimeTypeMap;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class MyAdapter extends BaseAdapter{
	private List<Node> allNodes;
	private List<Node> allNodesCache;
	private Context context;
	private LayoutInflater lif;
	private MyAdapter oThis = this;
	private Node root;
	private int expanderIcon=-1;
	private int collsapsedIcon=-1;
	private int type=0;// item object type
	ArrayList<String> Namerecord = new ArrayList<String>();
	private int mode;


	
	public MyAdapter(Context convertView,Node rootNode, int Mode){
		mode = Mode;
		allNodes = new ArrayList<Node>();
		allNodesCache= new ArrayList<Node>();
		root = rootNode;
		this.context=convertView;
		this.lif = (LayoutInflater) convertView.getSystemService(Service.LAYOUT_INFLATER_SERVICE);
		addAllnode(rootNode);
	}
	
	
	public int getCount() {
		// TODO Auto-generated method stub
		return allNodes.size();
	}

	
	public Object getItem(int position) {
		// TODO Auto-generated method stub
		return allNodes.get(position);
	}

	
	public long getItemId(int position) {
		// TODO Auto-generated method stub
		return position;
	}
	/****View��ʾ��*****/
	
	public View getView(int position, View convertView, ViewGroup parent) {
		
		ViewHolder holder = null;
		final Node node = allNodes.get(position);
		if(node.getOb().getClass().equals(Entity.class)){
			if(((Entity)node.getOb()).getE_type().equals("dir")){
				type = AppConfig.DIR_LIST;
			}
			if(((Entity)node.getOb()).getE_type().equals("file")){
				type = AppConfig.FILE_LIST;
			}
		}
		if(node.getOb().getClass().equals(Group.class))
			type = AppConfig.GROUP_LIST;
		if(node.getOb().getClass().equals(VMFile.class))
			type = AppConfig.FILE_LIST;
		if(node.getOb().getClass().equals(User.class))
			type = AppConfig.FRIEND_LIST;
		
		switch(type){
			case AppConfig.DIR_LIST:
				holder= new ViewHolder();
				convertView = this.lif.inflate(R.layout.single_file_group, null);
				//�õ�ҳ��ؼ�
				((ViewHolder)holder).groupName = (TextView) convertView.findViewById(R.id.file_group_name);
				
				//((FileViewHolder)holder).select = (CheckBox) convertView.findViewById(R.id.selectFile);
				convertView.setTag(holder);				
				if(node != null){			
						convertView.setBackgroundDrawable(null);
						
						((ViewHolder)holder).groupName.setText(((Entity)node.getOb()).getE_name());
						//((ViewHolder)holder).groupName.setTextColor(Color.BLACK);
						//convertView.setOnLongClickListener(new MyOnLongClickListener(position));				            
						//convertView.setOnDragListener(new MyFileDragEventListener(this, position));
						if(node.isExpanded){
							//holder.imageView.setImageResource(R.drawable.tree_ec);
						}else{
							//holder.imageView.setImageResource(R.drawable.tree_ex);
						}					
						convertView.setOnClickListener(new OnClickListener(){
							public void onClick(View v) {
								ExpandOrCollapse(allNodes.indexOf(node));									
							}							
						});					
				}
				convertView.setPadding(30*node.getLevel(), 5, 5, 5);
				break;
			case AppConfig.GROUP_LIST:			
				holder= new ViewHolder();
				convertView = this.lif.inflate(R.layout.single_file_group, null);
				//�õ�ҳ��ؼ�
				((ViewHolder)holder).groupName = (TextView) convertView.findViewById(R.id.file_group_name);
				
				//((FileViewHolder)holder).select = (CheckBox) convertView.findViewById(R.id.selectFile);
				convertView.setTag(holder);				
				if(node != null){			
						convertView.setBackgroundDrawable(null);
						
						((ViewHolder)holder).groupName.setText(((Group)node.getOb()).getGroupName());
						//((ViewHolder)holder).groupName.setTextColor(Color.BLACK);
						//convertView.setOnLongClickListener(new MyOnLongClickListener(position));				            
						//convertView.setOnDragListener(new MyFileDragEventListener(this, position));
						if(node.isExpanded){
							//holder.imageView.setImageResource(R.drawable.tree_ec);
						}else{
							//holder.imageView.setImageResource(R.drawable.tree_ex);
						}					
						convertView.setOnClickListener(new OnClickListener(){
							public void onClick(View v) {
								ExpandOrCollapse(allNodes.indexOf(node));									
							}							
						});					
				}
				convertView.setPadding(30*node.getLevel(), 5, 5, 5);				
				break;
			
			case AppConfig.FRIEND_LIST:
				holder = new ViewHolder();
				convertView = this.lif.inflate(R.layout.single_friend_user, null);
				((ViewHolder)holder).ava = (ImageView)convertView.findViewById(id.friend_user_ava);
				((ViewHolder)holder).userName = (TextView)convertView.findViewById(id.friend_user_name);
				((ViewHolder)holder).userStatus = (TextView)convertView.findViewById(id.friend_user_status);
				((ViewHolder)holder).userInfo = (TextView)convertView.findViewById(id.friend_user_info);
				((ViewHolder)holder).statusIcon = (ImageView)convertView.findViewById(id.friend_user_status_icon);
				((ViewHolder)holder).share = (Button)convertView.findViewById(id.friend_share_btn);
				((ViewHolder)holder).browser = (Button)convertView.findViewById(id.friend_view_btn);
				((ViewHolder)holder).chat = (Button)convertView.findViewById(id.friend_chat_btn);
				((ViewHolder)holder).remove = (Button)convertView.findViewById(id.friend_remove_btn);
				//((ViewHolder)holder).select = (CheckBox) convertView.findViewById(R.id.selectFriend);
				((ViewHolder)holder).select.setOnClickListener(new View.OnClickListener() {
					
					public void onClick(View v) {
						// TODO Auto-generated method stub
						node.setSelect(((CheckBox)v).isChecked());
						Log.i("check");
					}
				});
				final Bundle b = new Bundle();
				b.putString("Name", ((User)node.getOb()).getDispName());
				b.putString("Jid", ((User)node.getOb()).getJid());
				b.putString("Status", ((User)node.getOb()).getStatus());
				
				convertView.setTag(holder);
				if(node != null){						
					((ViewHolder)holder).userName.setText(((User)node.getOb()).getDispName());
					((ViewHolder)holder).userInfo.setText(((User)node.getOb()).getJid());
					((ViewHolder)holder).userStatus.setText(((User)node.getOb()).getStatus());
					((ViewHolder)holder).select.setChecked(node.isSelect);
					//convertView.setOnLongClickListener(new MyOnLongClickListener(position));				            
					//convertView.setOnDragListener(new MyFileDragEventListener(this, position));
				}
				
			convertView.setPadding(30*node.getLevel(), 5, 5, 5);
				
				break;
			case AppConfig.FILE_LIST:
								
				
				holder = new ViewHolder();
				convertView = this.lif.inflate(R.layout.single_file, null);
				//�õ�ҳ��ؼ�					
				((ViewHolder)holder).icon= (ImageView)convertView.findViewById(R.id.file_icon);					
				((ViewHolder)holder).fileName = (TextView) convertView.findViewById(R.id.file_name);
				((ViewHolder)holder).lastModifyTime = (TextView) convertView.findViewById(R.id.lastModifytime);
				if(((Entity)node.getOb()).getE_sharedBy() != null)
					((ViewHolder)holder).sharedBy = (TextView) convertView.findViewById(R.id.sharedBy);
				((ViewHolder)holder).select = (CheckBox) convertView.findViewById(R.id.selectFile);
				((ViewHolder)holder).select.setOnClickListener(new View.OnClickListener() {
					
					public void onClick(View v) {
						// TODO Auto-generated method stub
						node.setSelect(((CheckBox)v).isChecked());
						Log.i("check");
					}
				});
				convertView.setTag(holder);
					
				if(node != null){						
						((ViewHolder)holder).icon.setVisibility(View.VISIBLE);
						((ViewHolder)holder).icon.setBackgroundResource(R.drawable.icon);
						((ViewHolder)holder).fileName.setText(((Entity)node.getOb()).getE_name());
						((ViewHolder)holder).lastModifyTime.setText(((Entity)node.getOb()).getE_modate().toString());
						((ViewHolder)holder).select.setChecked(node.isSelect);
						if(((Entity)node.getOb()).getE_sharedBy() != null)
							((ViewHolder)holder).sharedBy.setText("Shared with: " + ((Entity)node.getOb()).getE_sharedBy());

						//convertView.setOnLongClickListener(new MyOnLongClickListener(position));				            
						//convertView.setOnDragListener(new MyFileDragEventListener(this, position));
				}

				
				convertView.setPadding(30*node.getLevel(), 5, 5, 5);
				convertView.setOnClickListener(new OnClickListener(){

					public void onClick(View v) {
						MobiCloudDroidActivity.notifyHandler(MsgDict.DES_UPDATE, node.getOb());
						
					}
					
				});
				break;
			default:
					break;
		}	
			
		//Log.i("level", allNodes.get(position).getLevel()+"");
		return convertView;
	}
	
	//���ݴ���ĸ��ڵ�  �õ���ǰ���нڵ�
	public void addAllnode(Node node){
		allNodes.add(node);
		allNodesCache.add(node);
		if(node.isLeaf())return;
		for(int i=0;i<node.getChildren().size();i++){
			addAllnode(node.getChildren().get(i));
		}
	}
	public void addNode(Node node){
		allNodes.add(node);
		allNodesCache.add(node);
				
	}
	
	public ArrayList<String> returnALLselectedName(Node r) {
		if(Namerecord!=null){
			Namerecord = new ArrayList<String>();
		}
		returnSelectedName(r);
		return Namerecord;
		
	}
	
	private void returnSelectedName(Node r) {
		for(int i=r.getChildren().size()-1; i>=0;i--){			
			if(r.getChildren().get(i).isLeaf()){
				if(r.getChildren().get(i).isSelect){
					if(r.getChildren().get(i).getOb().getClass().equals(Entity.class)){
						String name = (((Entity)r.getChildren().get(i).getOb()).getE_name());							
						Namerecord.add(name);
					}
					if(r.getChildren().get(i).getOb().getClass().equals(User.class)){
						String id = (((User)r.getChildren().get(i).getOb()).getJid());							
						Namerecord.add(id.split("@")[0]);
					}
					Log.i("record");
				}				
			}
			else{
				returnSelectedName(r.getChildren().get(i));
			}			
		}	
		
	}
	
	public void addNode(int pos, Node node){
		Node temp = (Node) getItem(pos-1);
		
		if(temp.getOb().getClass().equals(Group.class)){
			temp.add(node);
			node.setParent(temp);
			allNodes.add(pos+temp.getChildren().size()-1, node);
			allNodesCache.add(pos+temp.getChildren().size()-1, node);
			return;
		}
		else if(temp.getOb().getClass().equals(Entity.class)){
			if(((Entity)temp.getOb()).getE_type().equals("dir")){
				temp.add(node);
				node.setParent(temp);
				allNodes.add(pos+temp.getChildren().size()-1, node);
				allNodesCache.add(pos+temp.getChildren().size()-1, node);
				return;
			}
		}
			temp.getParent().getChildren().add(temp.getParent().getChildren().indexOf(temp)+1, node);
			node.setParent(temp.getParent());
			allNodes.add(pos, node);
			allNodesCache.add(pos, node);
			return;
		
	}
	
	
	
	
	
	public void removeNode(int pos, Node node){
		node.getParent().remove(node);
		allNodes.remove(pos);
		allNodesCache.remove(pos);
		
	}	
	
	
	//���û����ĳ��LIST��ʱ��  ���ƽڵ�����
	public void ExpandOrCollapse(int position){
		Node n = allNodes.get(position);
		//Log.i("���ǵ������", n.text+" isExpanded:"+n.isExpanded());
		if(n != null){
			if(!n.isLeaf()){
//				n.setExpanded(!n.isExpanded());
//				filterNode();
				if(!n.isExpanded){
					for(int i =0;i<n.getChildren().size();i++){
						//allNodes.add(n.getChildren().get(i));
						//����һ��������ʾ˳�������  Ҫ����ʾ�����ĸ��ڵ���
						//����Ľڵ�λ��
						allNodes.add(position+1+i, n.getChildren().get(i));
					}
				}else{
					for(int i =0;i<n.getChildren().size();i++){
						if(n.getChildren().get(i).isExpanded && 
								!n.getChildren().get(i).isLeaf()){
							ExpandOrCollapse(position+1+i);
						}						
					}
					for(int i =0;i<n.getChildren().size();i++){
						
						allNodes.remove(n.getChildren().get(i));
					}
				}	
				n.setExpanded(!n.isExpanded);
				this.notifyDataSetChanged();
			}
		}
	}
	
	//����Ĭ�ϴ�ʱչ������
	public void ExpanderLevel(int level){
		allNodes.clear();
		for(int i =0;i<allNodesCache.size();i++){
			//�õ�ÿһ���ڵ�
			Node n = allNodesCache.get(i);
			if(n.getLevel()<=level){
				if(n.getLevel()<level){
					n.setExpanded(true);
					
				}else{
					n.setExpanded(false);
				}
				allNodes.add(n);
			}else{
				n.setExpanded(false);
			}
		}
		oThis.notifyDataSetChanged();
	}
	//����ͼ��
	public void setIcon(int expandedIcon,int collsapsedIcon){
		this.expanderIcon = expandedIcon;
		this.collsapsedIcon= collsapsedIcon;
	}
	
	public void deleteAllSelectedNode() {
		deleteSelectedNode(root);
		oThis.notifyDataSetChanged();
	}
	
	public void refreshList() {
		oThis.notifyDataSetChanged();
	}
	
	
	List<String> pathrecord = new ArrayList<String>();
	ArrayList<String> IDrecord = new ArrayList<String>();
	ArrayList<Node> Itemrecord = new ArrayList<Node>();

	
	public List<String> returnALLselectedPath(Node r){
		returnALLselectedItem(r);
		List<String> str = new ArrayList<String>();
		for(Node i: Itemrecord){
			if(i.getOb().getClass().equals(Entity.class)){
				String path = (((Entity)i.getOb()).getE_url());							
				str.add(path);
			}
			
		}
		return str;
	}
	
	public ArrayList<Node> returnALLselectedItem(Node r) {
		if(Itemrecord!=null){
			Itemrecord = new ArrayList<Node>();
		}
		returnSelectedItem(r);
		return Itemrecord;		
	}
	
	private void returnSelectedItem(Node r) {
		for(int i=r.getChildren().size()-1; i>=0;i--){			
			if(r.getChildren().get(i).isLeaf()){
				if(r.getChildren().get(i).isSelect){
					Node n = r.getChildren().get(i);							
					Itemrecord.add(n);
				}				
			}
			else{
				returnSelectedItem(r.getChildren().get(i));
			}			
		}	
		
	}
	
	public void returnSelectedPath(Node r){		
		for(int i=r.getChildren().size()-1; i>=0;i--){			
			if(r.getChildren().get(i).isLeaf()){
				if(r.getChildren().get(i).isSelect){
					if(r.getChildren().get(i).getOb().getClass().equals(VMFile.class)){
						String path = (((VMFile)r.getChildren().get(i).getOb()).getPath());							
						pathrecord.add(path);
					}					
					Log.i("record");
				}				
			}
			else{
				returnSelectedPath(r.getChildren().get(i));
			}			
		}		
	}
	
	
	public void deleteSelectedNode(Node r) {
		
		for(int i=r.getChildren().size()-1; i>=0;i--){			
			if(r.getChildren().get(i).isLeaf()){
				if(r.getChildren().get(i).isSelect){					
					if(r.isExpanded()){
						allNodes.remove(r.getChildren().get(i));
						allNodesCache.remove(r.getChildren().get(i));
					}
					r.remove(i);
					Log.i("delete");
				}				
			}
			else{
				deleteSelectedNode(r.getChildren().get(i));
			}			
		}		
	}


	public void selectAllNode(boolean checked) {
		selectNode(root, checked);
		oThis.notifyDataSetChanged();
	}
	
	public void deleteNode(Node r) {
		if(r.isRoot())
			return;
		for(int i=r.getChildren().size()-1; i>=0;i--){			
			if(r.getChildren().get(i).isLeaf()){									
				if(r.isExpanded()){
					allNodes.remove(r.getChildren().get(i));
					allNodesCache.remove(r.getChildren().get(i));
				}
				//r.remove(i);										
			}
			else{
				deleteNode(r.getChildren().get(i));
			}			
		}
		allNodes.remove(r);
		r.getParent().remove(r);
	}


	public void selectNode(Node r, boolean checked) {
		for(int i=0; i<r.getChildren().size();i++){
			if(r.getChildren().get(i).isLeaf()){
				r.getChildren().get(i).setSelect(checked);			
			}
			else{
				selectNode(r.getChildren().get(i), checked);
			}
		}		
	}
	
	public class ViewHolder{
		//attributes of friend list item
		ImageView ava ;
		Button remove;
		Button chat;
		Button browser;
		Button share;
		ImageView statusIcon;
		TextView userInfo;
		TextView userStatus;
		TextView userName;
		
		//attributes of group
		ImageView groupIcon;
		TextView groupName ;
		CheckBox select ;
		
		//attributes of file list item
		ImageView icon ;		
		TextView fileName;
		TextView lastModifyTime;
		TextView sharedBy;
		
	}

	public ArrayList<String> returnALLselectedID(Node r) {
		if(IDrecord!=null){
			IDrecord = new ArrayList<String>();
		}
		returnSelectedID(r);
		return IDrecord;
		
	}


	private void returnSelectedID(Node r) {
		for(int i=r.getChildren().size()-1; i>=0;i--){			
			if(r.getChildren().get(i).isLeaf()){
				if(r.getChildren().get(i).isSelect){
					if(r.getChildren().get(i).getOb().getClass().equals(Entity.class)){
						String id = (((Entity)r.getChildren().get(i).getOb()).getE_id());							
						IDrecord.add(id);
					}
					if(r.getChildren().get(i).getOb().getClass().equals(User.class)){
						String id = (((User)r.getChildren().get(i).getOb()).getJid());							
						IDrecord.add(id);
					}
					Log.i("record");
				}				
			}
			else{
				returnSelectedID(r.getChildren().get(i));
			}			
		}	
		
	}


	public void setAllSelectedPermission(int p) {
		setSeletedPermission(Global.FriendTreeRootNode.getChildren().get(1),p);
		
	}


	private void setSeletedPermission(Node r, int p) {
		// TODO Auto-generated method stub
		for(int i=r.getChildren().size()-1; i>=0;i--){			
			if(r.getChildren().get(i).isLeaf()){
				if(r.getChildren().get(i).isSelect){
					if(r.getChildren().get(i).getOb().getClass().equals(Entity.class)){												
						switch(p){
						case MsgDict.PUBLIC:
							break;
						case MsgDict.PRIVATE:
							break;
						case MsgDict.SHARED:
							break;
						}
						
					}
					
					Log.i("record");
				}				
			}
			else{
				returnSelectedID(r.getChildren().get(i));
			}			
		}
	}



	
}
