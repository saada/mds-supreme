package Mobi.UI;

import java.io.BufferedInputStream;    
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;

import log.Log;

import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smack.packet.Presence.Mode;
import xmpp.JabberSmackAPI;
import xmpp.Manager;

import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.media.AudioManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.os.Vibrator;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.View.OnClickListener;
import android.widget.AbsListView;
import android.widget.BaseAdapter;
import android.widget.BaseExpandableListAdapter;
import android.widget.EditText;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.QuickContactBadge;
import android.widget.TextView;
import android.widget.Button;
import android.widget.Toast;
import android.widget.ExpandableListView.ExpandableListContextMenuInfo;
import Mobi.config.AppConfig;
import Mobi.config.MsgDict;
import Mobi.tree.MyAdapter;
import Mobi.tree.Node;
import Mobi.xmpp.Entity;
import Mobi.xmpp.File;
import Mobi.xmpp.FileGroup;
import Mobi.xmpp.FullRoster;
import Mobi.xmpp.User;
import Mobi.xmpp.XMPPConnectionManager;
import Mobi.xmpp.XMPPService;

//MAIN ACTIVITY
public class MobiCloudDroidActivity extends Activity {
	
	
	private static Handler handler_;
	protected MyAdapter fileListAdapter_; //= new MyAdapter(this, Global.FileTreeRootNode);

	/** Called when the activity is first created. */
    
	static JabberSmackAPI api = new JabberSmackAPI();


	private Dialog dialog;
	private Vibrator vbrator_;
	private int stage_;
	private XMPPService service_;
	
	public Manager getManager()
	{
		return Global.MANAGER;
	}
    
    
    @Override
    public void onCreate(Bundle savedInstanceState) {
        //setTheme(android.R.style.Theme_Light);

        super.onCreate(savedInstanceState);
        fileListAdapter_ = new MyAdapter(this, Global.FileTreeRootNode, 0);
        initializeHandler();

        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
				WindowManager.LayoutParams.FLAG_FULLSCREEN);
		this.setVolumeControlStream(AudioManager.STREAM_MUSIC);
		vbrator_ = (Vibrator) getSystemService(Context.VIBRATOR_SERVICE);
        setContentView(R.layout.login);
        initializelogin();       
    }
	    
	/////////////////////////////////////
	/////// Handler Initialization //////
	/////////////////////////////////////
    private void initializeHandler() {
		handler_ = new Handler(this.getMainLooper()) {
			public void handleMessage(Message msg) {
				switch (msg.what) {
				case MsgDict.C_PRESENCE_CHANGED:{
					//updateView(AppConfig.STAGE_CONTACTS);
				}
					break;
				case MsgDict.CHAT_REQUEST:
					
					break;
					
				case MsgDict.FILELIST_UPDATE:{
					Global.VMFileNode = (Node) msg.obj;
					for(int i=0; i<Global.FileTreeRootNode.getChildren().size();i++){
						Node n = Global.FileTreeRootNode.getChildren().get(i);
						Entity tp = (Entity)n.getOb();
						if(tp.getE_name().equals("VMFILE")){
							fileListAdapter_.deleteNode(n);													
						}
					}									
					Global.FileTreeRootNode.add(Global.VMFileNode);
					
					fileListAdapter_.addNode(Global.VMFileNode);
					//list.invalidate();
					Log.i("add node successfully");
					//updateView(AppConfig.STAGE_MYFILES);					
					break;
				}
				case MsgDict.DES_UPDATE:{
					Global.f = (Entity) msg.obj;
					/*des.setVisibility(View.VISIBLE);
					filename.setText("FILE NAME: "+f.getE_name());
					filesize.setText("FILE SIZE: "+f.getE_size().toString()+" Byte");
					url.setText("Path: "+ f.getE_url());
					modifytime.setText("MODIFIED DATE: "+f.getE_modate().toString());
					sharewith.setText("SHARE WITH: " + f.getE_sharedBy().toString());
					*/
					break;
				}
				
				case MsgDict.USERPERMISSION_REQUEST_SUCCESSFUL:{
					//final int p = (Integer) msg.obj;
					Global.MANAGER.RequestFileList(Global.MANAGER.getConn_().getUser(),Global.MANAGER.getConn_().getUser().split("/")[0]+"/VM");					
					break;
				}
				case MsgDict.USERPERMISSION_REQUEST_FAILED:{
					
					break;
				}
				case MsgDict.DELETE_REQUEST_SUCCESSFUL:{
					fileListAdapter_.deleteAllSelectedNode();
					System.out.println("one fish two fish we are all fish");
					fileListAdapter_.notifyDataSetChanged();

					break;
				}
				case MsgDict.DELETE_REQUEST_FAILED:{					
	
					break;
				}
				case MsgDict.UPLOAD_REQUEST_SUCCESSFUL:{
					System.out.println("SUCCESSSSSSSSSSSSSSSSSSSSSSSS");
					break;
				}
				case MsgDict.CREATEDIRECTORY_REQUEST_SUCCESSFUL:{
					break;
				}
				case MsgDict.CREATEDIRECTORY_REQUEST_FAILED:{
					break;
				}
				case MsgDict.RENAME_REQUEST_SUCCESSFUL:{
					break;
				}
				case MsgDict.RENAME_REQUEST_FAILED:{
					break;
				}
				
				case MsgDict.SHARE_FILE_REQUEST:{					

					break;
				}
					
					
				}
			}
		};
		
	}

	public static Handler getHandler() {
		return handler_;
	}
	
	public static void notifyHandler(int what, Object obj) {
		android.os.Message message = new android.os.Message();
		message.what = what;
		message.obj = obj;
		if (handler_ != null) {
		handler_.sendMessage(message);
		}
	}
  
    protected boolean checkaccount(String username, String password){
    	//SET UP XMPP CONNECTION
    	Global.MANAGER = new Manager(0, username, password, false, 2, 1, "vm");
		api.setConnection(Global.MANAGER.getXMPPConnection());
		
		// DELETE WHEN CAN CONNECT W/OPENFIRE SERVER
		//return true;
		
		// UNCOMMENT WHEN CAN CONNECT W/OPENFIRE SERVER
		if(!Global.MANAGER.login())
		{
			if(!Global.MANAGER.login())
			{
				return false;
			}
		}
		return true;
		
    }

	protected void initializelogin(){
		Button login = (Button)findViewById(R.id.login);
        findViewById(R.id.username_label);
        findViewById(R.id.password_label);
        final EditText username =(EditText)findViewById(R.id.username);
        final EditText password =(EditText)findViewById(R.id.password);
        login.setOnClickListener(new OnClickListener(){
        	public void onClick(View v){
        		if(checkaccount(username.getText().toString(),password.getText().toString())){
        			//api.setConnection(MANAGER.getXMPPConnection());
        			
        			//load some sample files
        			String one = "this is a test file used to determine if we can read files from the internal storage";
				      try {
						FileOutputStream fos = openFileOutput("test2.txt", Context.MODE_PRIVATE);
						fos.write(one.getBytes());
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
        			       			
        			initializeUI();
        			//showView(AppConfig.STAGE_CONTACTS);        			        			
        		}
        		else{
        			initializedialog();
        		}
        			
        	}
        });
    }
	
	
    protected void initializeUI() {
		try{
		Intent tabs = new Intent(MobiCloudDroidActivity.this, BackupRestoreActivity.class);
		MobiCloudDroidActivity.this.startActivity(tabs);	
		}
		catch(Exception e)
		{ 
			System.out.print(e);
		}	
	}
    
    protected QuickContactBadge ownBadge;
    protected TextView MsgTopLine;
    protected EditText searchBar;
    protected Button searchBtn;
    
    protected Button contactsBtn;
    protected Button my_filesBtn;
    protected Button settingsBtn;
    protected Button logoutBtn;
    
	
	protected View contactsView_;
	protected ListView friendLV_;
	protected TextView friendListEmptyTV_;
	protected FullRoster fullRoster_;
	

	protected Dialog userDialog_;
	protected ImageView userDlgAvatarIV_;
	protected TextView userDlgDispNameTV_;
	protected View shareView;
	protected ListView my_fileLV;
	protected FileListAdapter my_fileListAdapter_;
	protected Button userDlgShareTestFileBtn_;
	protected View chatView_;
	protected EditText chatContentET_;
	protected Button chatSendBtn_;
	protected ImageView chatAvaIV_;
	protected TextView chatHistoryTV_;
	protected Button chatDisconnectBtn_;
	protected Button userDlgCloseBtn_;
	protected User selectedUser_ = null;
	
	protected class FileListAdapter extends BaseAdapter{
		private LayoutInflater inflater_;		
		
		private Object[] file= new Object[2];	
		
		public FileListAdapter(Activity context) {
			inflater_ = context.getLayoutInflater();
			file[0] = new String();
			file[0] = "Documents";			
			file[1] = new File();
			((File) file[1]).setFileName("test2.txt");
			((File) file[1]).setFileOwner(Global.MANAGER.getEmail());
			((File) file[1]).setLastModifyTime("modified on 10/11/2011");
			/*file[2] = new File();
			((File) file[2]).setFileName("X-factor.mp3");
			((File) file[2]).setFileOwner("Yu Liu");
			((File) file[2]).setLastModifyTime("modified on 11/19/2011");
			file[3] = new File();			
			((File) file[3]).setFileName("illusions.ape");
			((File) file[3]).setFileOwner("Xin Du");
			((File) file[3]).setLastModifyTime("modified on 10/14/2011");
			file[4] = new String();
			file[4] = "Video";
			file[5] = new File();			
			((File) file[5]).setFileName("Star Trek");
			((File) file[5]).setFileOwner("???");
			((File) file[5]).setLastModifyTime("modified on 9/11/2011");*/
						
		}

		public int getCount() {
			
			return file.length;
			
			/*
			int sum = 0;
			for (int i = 0; i < getGroupCount(); i++) {
				sum += (getChildrenCount(i) + 1);
			}
			return sum;
			*/
		}

		public int getGroupCount() {
			try {
				return fullRoster_.size();
			} catch (Exception e) {
				return 0;
			}
		}

		public int getChildrenCount(int groupPosition) {
			FileGroup grp = (FileGroup) getGroup(groupPosition);
			if (grp == null) {
				return 0;
			} else {
				return 0;
			}
		}

		public Object getGroup(int groupPosition) {
			return fullRoster_.getGroup(groupPosition);
		}


		public Object getItem(int childPosition) {
			
			if(childPosition<file.length)
				return file[childPosition];
			else
				return null;
			
/*
			for (int i = 0; i < getGroupCount(); i++) {
				if (childPosition > ((UserGroup) getGroup(i)).size()) {
					childPosition -= (((UserGroup) getGroup(i)).size() + 1);
				} else {
					if (childPosition == 0) {
						String n = ((UserGroup) getGroup(i)).name + " ("
								+ ((UserGroup) getGroup(i)).size() + ")";
						return n;
					} else {
						User user = ((UserGroup) getGroup(i))
								.getUser(childPosition - 1);
						return user;
					}
				}
			}
			return null;
			
*/
		}
	


		public long getItemId(int position) {
			return position;
		}


		public View getView(int position, View view, ViewGroup parent) {
			try {
				Object obj = getItem(position);
				if (obj == null) {
					view = null;
				} else if (obj.getClass().equals(String.class)) {
					view = inflater_
							.inflate(R.layout.single_friend_group, null);
					view
							.findViewById(R.id.friend_group_icon);
					TextView name = (TextView) view
							.findViewById(R.id.friend_group_name);

					name.setText((String) obj);
				} else if (obj.getClass().equals(File.class)) {
					File file = (File) obj;
					view = inflater_.inflate(R.layout.single_file, null);
					ImageView icon = (ImageView) view.findViewById(R.id.file_icon);
					TextView fileName = (TextView) view
							.findViewById(R.id.file_name);
					TextView lastModifyTime = (TextView) view
							.findViewById(R.id.lastModifytime);
					//TextView fileOwner = (TextView) view
					//		.findViewById(R.id.file_owner);
					

					//if (file.getFileName().endsWith("/vm")) {
						icon.setImageResource(R.drawable.index);
					/*} else {
						icon.setImageResource(R.drawable.defaultava);
					}*/
					
					fileName.setText(file.getFileName());
					//fileOwner.setText(file.getFileOwner());
					lastModifyTime.setText(file.getLastModifyTime());				
					
					
				}
				return view;
			} catch (Exception e) {
				e.printStackTrace();
				return null;
			}
		}
	}	
	
	protected View groups;
	protected ExpandableListView list;
	protected ExpandableListAdapter myFiles;	
	boolean isDocument, isMusic, isPicture;
	protected TextView textView1;
	
	
	private void initializeMyFilesView() {
		groups = (View)findViewById(R.id.groups);
        
        // Set up our adapter
        myFiles = new MyExpandableListAdapter();
        list.setAdapter(myFiles);
        registerForContextMenu(list);
        
        //@Override
        (list).setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            @SuppressWarnings("null")
			public boolean onChildClick(ExpandableListView parent,
                    View v, int groupPosition, int childPosition,
                    long id) {
            	
                if (groupPosition == 0 ) 
                {
                	// load document viewer
                	textView1.setText("Load " + myFiles.getChild(groupPosition, childPosition));
                }
                if (groupPosition == 0 ) 
                {
                	// load document viewer
                	//Find the directory for the SD Card using the API
                	//*Don't* hardcode "/sdcard"
                	//File sdcard = Environment.getExternalStorageDirectory();
                	
                	String text = "";
                	
                    try{
                        // Open the file that is the first 
                        // command line parameter
                        FileInputStream fis = openFileInput("test2.txt");
                        InputStream in = new BufferedInputStream(fis);
                        //Read File Line By Line
                        byte[] buffer = null;
                        in.read( buffer);
                          // Print the content on the console
                          text += buffer.toString();
                        
                        //Close the input stream
                        in.close();
                        }catch (Exception e){//Catch exception if any
                          text += ("Error: " + e.getMessage());
                        }



                	textView1.setText(text);
                }
                
                return true;
            }
            });
	}
	@Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        menu.setHeaderTitle("Sample menu");
        menu.add(0, 0, 0, "My Files");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        ExpandableListContextMenuInfo info = (ExpandableListContextMenuInfo) item.getMenuInfo();

        String title = ((TextView) info.targetView).getText().toString();

        int type = ExpandableListView.getPackedPositionType(info.packedPosition);
        if (type == ExpandableListView.PACKED_POSITION_TYPE_CHILD) {
            int groupPos = ExpandableListView.getPackedPositionGroup(info.packedPosition); 
            int childPos = ExpandableListView.getPackedPositionChild(info.packedPosition); 
            Toast.makeText(this, title + ": Child " + childPos + " clicked in group " + groupPos,
                    Toast.LENGTH_SHORT).show();
            return true;
        } else if (type == ExpandableListView.PACKED_POSITION_TYPE_GROUP) {
            int groupPos = ExpandableListView.getPackedPositionGroup(info.packedPosition); 
            Toast.makeText(this, title + ": Group " + groupPos + " clicked", Toast.LENGTH_SHORT).show();
            return true;
        }

        return false;
    }
	public class MyExpandableListAdapter extends BaseExpandableListAdapter {
        // Sample data set.  children[i] contains the children (String[]) for groups[i].
        private String[] folders = { "Documents" };
        private String[][] files = {
                { "test2.txt" }
        };

        public Object getChild(int groupPosition, int childPosition) {
            return files[groupPosition][childPosition];
        }

        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }

        public int getChildrenCount(int groupPosition) {
            return files[groupPosition].length;
        }

        public TextView getGenericView() {
            // Layout parameters for the ExpandableListView
            AbsListView.LayoutParams lp = new AbsListView.LayoutParams(
                    ViewGroup.LayoutParams.FILL_PARENT, 64);

            TextView textView = new TextView(MobiCloudDroidActivity.this);
            textView.setLayoutParams(lp);
            // Center the text vertically
            textView.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
            // Set the text starting position
            textView.setPadding(36, 0, 0, 0);
            return textView;
        }

        public View getChildView(int groupPosition, int childPosition, boolean isLastChild,
                View convertView, ViewGroup parent) {
            TextView textView = getGenericView();
            textView.setText(getChild(groupPosition, childPosition).toString());
            return textView;
        }

        public Object getGroup(int groupPosition) {
            return folders[groupPosition];
        }

        public int getGroupCount() {
            return folders.length;
        }

        public long getGroupId(int groupPosition) {
            return groupPosition;
        }

        public View getGroupView(int groupPosition, boolean isExpanded, View convertView,
                ViewGroup parent) {
            TextView textView = getGenericView();
            textView.setText(getGroup(groupPosition).toString());
            return textView;
        }

        public boolean isChildSelectable(int groupPosition, int childPosition) {
            return true;
        }

        public boolean hasStableIds() {
            return true;
        }      
    }
	
	protected View settingsView_;
	private void initializeSettingView() {
		
	}
	
	protected void initializeconfirmlogout(){
    	final Dialog dlg = StyledConfirmDialog.create("comfirm", "do you really want to log out?", MobiCloudDroidActivity.this);
		StyledConfirmDialog.yesButton(dlg, "Yes", new OnClickListener() {
					public void onClick(View v) {
						setContentView(R.layout.login);						
						dlg.dismiss();
					}
				});
		StyledConfirmDialog.noButton(dlg, "No", null);
		dlg.show();
    }
	
    protected void initializedialog(){   	
        dialog = new Dialog(this, android.R.style.Theme_Dialog);
        dialog.setContentView(R.layout.alert_dialog);
        dialog.setTitle("Alert Dialog");
        TextView text_title = (TextView) dialog.findViewById(R.id.alert_title);
        TextView text_content = (TextView) dialog.findViewById(R.id.alert_content);
        text_title.setText("warning");
        text_content.setText("wrong username or password");
        Button alert_close = (Button) dialog.findViewById(R.id.alert_close);
        alert_close.setOnClickListener(new OnClickListener() {

			public void onClick(View v) {
				dialog.dismiss();
			}
		});
        dialog.show();
    }
    
 	protected void hideCurrentView() {
 		switch (stage_) {
 		case AppConfig.STAGE_CONTACTS: {
 			contactsView_.setVisibility(View.INVISIBLE);
 		}
 			break;
 		case AppConfig.STAGE_MYFILES: {
 			groups.setVisibility(View.INVISIBLE);
 		}
 			break;
 		case AppConfig.STAGE_SETTINGS: {
 			settingsView_.setVisibility(View.INVISIBLE);
 		}
 			break;
 		}
 	}
    
    protected void showView(int stage) {
		if (stage == stage_)
			return;
		hideCurrentView();
		doShowView(stage);
	}

	protected void updateView(int stage) {
		if (stage != stage_)
			return;
		doShowView(stage);
	}
	

	
	private void doShowView(int stage) {
		switch (stage) {
/*		case AppConfig.STAGE_LOGIN: {
			contactsBtn
					.setBackgroundResource(R.drawable.top_button_right_clicked);
			contactsView_.setVisibility(View.VISIBLE);
			accountListAdapter_.notifyDataSetChanged();
			// accountListAdapter_.notifyDataSetInvalidated();
			if (accountListAdapter_.getCount() == 0) {
				friendsListEmptyTV_.setVisibility(View.VISIBLE);
				friendsLV_.setVisibility(View.GONE);
			} else {
				friendsListEmptyTV_.setVisibility(View.GONE);
				friendsLV_.setVisibility(View.VISIBLE);
			}
			stage_ = AppConfig.STAGE_ACCOUNT;
		}
			break;
*/			
		case AppConfig.STAGE_CONTACTS: {
//			contactsBtn
//					.setBackgroundResource(R.drawable.top_button_center_clicked);
			contactsView_.setVisibility(View.VISIBLE);
			//friendListAdapter_.notifyDataSetChanged();
			// rosterListAdapter_.notifyDataSetInvalidated();
			//if (friendListAdapter_.getCount() == 0) {
			//	friendListEmptyTV_.setVisibility(View.VISIBLE);
			//	friendLV_.setVisibility(View.GONE);
			//} else {
			//	friendListEmptyTV_.setVisibility(View.GONE);
			//	friendLV_.setVisibility(View.VISIBLE);
			//}
			stage_ = AppConfig.STAGE_CONTACTS;
		}
			break;
		case AppConfig.STAGE_MYFILES: {

//			my_filesBtn
//					.setBackgroundResource(R.drawable.top_button_left_clicked);
			groups.setVisibility(View.VISIBLE);
			stage_ = AppConfig.STAGE_MYFILES;

			
		}
			break;
		case AppConfig.STAGE_SETTINGS: {
			
			settingsView_.setVisibility(View.VISIBLE);
			stage_ = AppConfig.STAGE_SETTINGS;

		}
		
			break;
		}
	}
	
	protected String getModeString(Presence.Mode mode) {
		if (mode == Mode.available) {
			return "(Online)";
		} else if (mode == Mode.away) {
			return "(Away)";
		} else if (mode == Mode.chat) {
			return "(Online)";
		} else if (mode == Mode.dnd) {
			return "(Busy)";
		} else if (mode == Mode.xa) {
			return "(Idle)";
		}
		return "";
	}
	
	protected XMPPConnectionManager getXMPPConnectionManager() {
		if (service_ == null || service_.getXMPPConnectionManager() == null) {
			return null;
		} else {
			return service_.getXMPPConnectionManager();
		}
	}
}