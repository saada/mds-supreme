package Mobi.UI;

import log.Log;

import org.jivesoftware.smack.Chat;
import org.jivesoftware.smack.ChatManagerListener;
import org.jivesoftware.smack.ConnectionListener;
import org.jivesoftware.smack.MessageListener;
import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;

import android.app.Activity;
import android.app.Instrumentation;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;

public class ChatActivity extends Activity{
	
	Bundle b;
	protected Button sendButton;
	protected TextView chatView;
	protected EditText userInput;
	protected LinearLayout theme;
	Activity Othis = this;
	String to;
	public MessageListener listener;

	
	@Override
	public void onCreate(Bundle savedInstanceState) {
	
		super.onCreate(savedInstanceState); 	
		setContentView(R.layout.chat);
		b = this.getIntent().getExtras();
		to = b.getString("Jid");
		theme = (LinearLayout) findViewById(R.id.themeLayout);
		chatView = (TextView) findViewById(R.id.textViewChatHistory);
		sendButton = (Button) findViewById(R.id.buttonSend);
		userInput = (EditText) findViewById(R.id.editTextStuff);
		
		chatView.append("\n"+ to + ": hi");
		// THEME STUFF
		if(Global.theTheme ==1)
		{
        	theme.setBackgroundColor(Color.WHITE);
        	chatView.setTextColor(Color.BLACK);
        	
		}
		sendButton.setOnClickListener(new OnClickListener()
		{
			@Override
			public void onClick(View theView) {
				
                
				String str = userInput.getText().toString();
				chatView.append("\nMe: "+str);
			    new Thread(new Runnable() {         
			        @Override
			        public void run() {
			            try {
			            Instrumentation inst = new Instrumentation();
			                inst.sendKeyDownUpSync(KeyEvent.KEYCODE_ENTER);
			                Thread.sleep(2000);
			                inst.sendKeyDownUpSync(KeyEvent.KEYCODE_BACK);
			                Thread.sleep(2000);
			            }
			            catch(InterruptedException e){
			            }
			        }   
			    }).start();
			    //send message that user has entered via XMPP
				Global.MANAGER.sendMessage(str, to, listener);		
                userInput.setText("");
			}
		});
		
		listener = new MessageListener(){
			public void processMessage(Chat cm, final Message message)
	        {
	        	Log.i("receive:"+message.getBody());
				if (message.getType() == Message.Type.chat){
					Handler h = new Handler(Othis.getMainLooper());
					h.post(new Runnable(){
						public void run() {							
							chatView.append("\n"+ to + ": "+ message.getBody());
						}						
					});
				}					
				Log.i("receive:"+message.getBody());
	        }
		};
		Global.MANAGER.getXMPPConnection()
		.getChatManager().addChatListener(new ChatManagerListener(){
			
			public void chatCreated( Chat c,  boolean createdLocally)
		    {
				//Log.i("receive chat:"+c.getBody());
				if (!createdLocally)
				{
					Log.i("receive remote chat:");
		    		c.addMessageListener(listener);
				}
		    }
		  });
		try {
		Global.MANAGER.getXMPPConnection().getChatManager().createChat(to, listener);
		} catch (Exception e)
		{ System.out.println(e);
		}
	
	}

}
