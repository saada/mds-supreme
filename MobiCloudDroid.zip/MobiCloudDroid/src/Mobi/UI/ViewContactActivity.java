package Mobi.UI;

import java.io.BufferedReader; 
import java.io.File;
import java.io.FileReader;
import java.io.IOException;

import android.app.ExpandableListActivity; 
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseExpandableListAdapter;
import android.widget.Button;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.ExpandableListContextMenuInfo;
import android.widget.TextView;
import android.widget.Toast;

public class ViewContactActivity extends ExpandableListActivity {
	
	ExpandableListAdapter contactFiles;
	
	boolean isDocument, isMusic, isPicture;

	protected TextView textView1;
	
    /** Called when the activity is first created. */
	@Override
    public void onCreate(Bundle savedInstanceState) {
        if(Global.theTheme ==1)
        	setTheme(android.R.style.Theme_Light);

		super.onCreate(savedInstanceState);       
        
        setContentView(R.layout.view_contact);      
        
        // Customize with name
        TextView contactText = (TextView) findViewById(R.id.textViewContact);
        Bundle b = this.getIntent().getExtras();
        contactText.setText( b.getString("contactName"));
        
        // Set up our adapter
        contactFiles = new MyExpandableListAdapter();
        setListAdapter(contactFiles);
        registerForContextMenu(getExpandableListView());
        
        
        //@Override
        (getExpandableListView()).setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            public boolean onChildClick(ExpandableListView parent,
                    View v, int groupPosition, int childPosition,
                    long id) {
            	           
                return true;
            }
            });     
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        TextView t = new TextView(this);
        t.setText("filename.ext details\nLast modified:\nSize:");
        menu.setHeaderView(t);
        menu.add(0, 0, 0, "Open");
        menu.add(0, 0, 1, "Download");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        ExpandableListContextMenuInfo info = (ExpandableListContextMenuInfo) item.getMenuInfo();

		if(item.getItemId() == 0)
        {
        	//OPEN FILE
            Toast.makeText(this, "open file!", Toast.LENGTH_SHORT).show();
            return true;
        }
        if(item.getItemId() == 1)
        {
        	//MAKE PUBLIC
        	Toast.makeText(this, "File downloaded", Toast.LENGTH_SHORT).show();            return true;
        }

        return false;
    }


    public class MyExpandableListAdapter extends BaseExpandableListAdapter {
        // Sample data set.  children[i] contains the children (String[]) for groups[i].
        private String[] folders = { "     Documents", "     Music", "     Pictures" };
        private String[][] files = {
                { "shared_file.txt", "eBook.pdf" },
                { "fav_song.mp3", "other_song.mp3" },
                { "funny_picture.jpeg", "cool_picture.jpeg" }
        };

        public Object getChild(int groupPosition, int childPosition) {
            return files[groupPosition][childPosition];
        }

        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }

        public int getChildrenCount(int groupPosition) {
            return files[groupPosition].length;
        }

        public TextView getGenericView() {
            // Layout parameters for the ExpandableListView
            AbsListView.LayoutParams lp = new AbsListView.LayoutParams(
                    ViewGroup.LayoutParams.FILL_PARENT, 64);

            TextView textView = new TextView(ViewContactActivity.this);
            textView.setLayoutParams(lp);
            // Center the text vertically
            textView.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
            // Set the text starting position
            textView.setPadding(36, 0, 0, 0);
            return textView;
        }

        public View getChildView(int groupPosition, int childPosition, boolean isLastChild,
                View convertView, ViewGroup parent) {
            TextView textView = getGenericView();
            textView.setText(getChild(groupPosition, childPosition).toString());
            return textView;
        }

        public Object getGroup(int groupPosition) {
            return folders[groupPosition];
        }

        public int getGroupCount() {
            return folders.length;
        }

        public long getGroupId(int groupPosition) {
            return groupPosition;
        }

        public View getGroupView(int groupPosition, boolean isExpanded, View convertView,
                ViewGroup parent) {
            TextView textView = getGenericView();
            textView.setText(getGroup(groupPosition).toString());
            return textView;
        }

        public boolean isChildSelectable(int groupPosition, int childPosition) {
            return true;
        }

        public boolean hasStableIds() {
            return true;
        }
    }
}