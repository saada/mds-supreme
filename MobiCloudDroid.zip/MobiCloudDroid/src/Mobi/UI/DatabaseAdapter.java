package Mobi.UI;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

public class DatabaseAdapter {
	public static final String KEY_ROWID = "id";
	public static final String KEY_LOGIN = "login";
	public static final String KEY_PW = "pw";
	public static final String KEY_SIGNIN = "signin";
	public static final String KEY_SETTING_ID = "setting_id";
	public static final String KEY_PRESENCE = "presence"; 
	public static final String KEY_STATUS = "status";

	private static final String TAG = "DBAdapter"; 

	private static final String DATABASE_NAME = "chat_db";

	private static final String DATABASE_ACCOUNT_TABLE = "account";
	private static final int DATABASE_VERSION = 1;

	private static final String CREATE_ACCOUNT_TABLE = "CREATE TABLE account ( "
			+ "id integer PRIMARY KEY autoincrement,"
			+ "login text NOT NULL,"
			+ "pw text NOT NULL," 
			+ "signin integer NOT NULL,"
			+ "setting_id integer NOT NULL DEFAULT 0,"
			+ "presence integer NOT NULL DEFAULT 1," + "status text NOT NULL);";

	private final Context context;
	private DatabaseHelper DBHelper;
	private SQLiteDatabase db;

	public DatabaseAdapter(Context ctx) {
		this.context = ctx;
		DBHelper = new DatabaseHelper(context);
	}
 
	private static class DatabaseHelper extends SQLiteOpenHelper {
		DatabaseHelper(Context context) {
			super(context, DATABASE_NAME, null, DATABASE_VERSION);
		}

		@Override
		public void onCreate(SQLiteDatabase db) {
			db.execSQL(CREATE_ACCOUNT_TABLE);
		}

		@Override
		public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
			Log.w(TAG, "Upgrading database from version " + oldVersion + " to "
					+ newVersion + ", which will destroy all old data");
			db.execSQL("DROP TABLE IF EXISTS " + DATABASE_ACCOUNT_TABLE);
			onCreate(db);
		}
	}

	/**
	 * Open db connection
	 * 
	 * @return DatabaseAdapter
	 * @throws SQLException
	 */
	public DatabaseAdapter open() throws SQLException {
		db = DBHelper.getWritableDatabase();
		return this;
	}

	/**
	 * Close db connection
	 */
	public void close() {
		DBHelper.close();
	}

	/**
	 * Insert an XMPP account
	 * 
	 * @param login
	 *            Email
	 * @param pw
	 *            Password in plain text
	 * @param signin
	 *            true = 1, false = 0. Indicates if the account is auto-sign-in
	 * @param settingId
	 *            Default = 0. Different XMPP servers have diff settings for
	 *            sign in. Users can also create custom sign in setting. Diff
	 *            settings are stored in db with a setting id.
	 * @param presence
	 *            1 = available, 0 = unavailable
	 * @param status
	 *            user's status message string
	 * @return
	 */
	public long insert(String login, String pw, boolean signin, int settingId,
			int presence, String status) {
		ContentValues initialValues = new ContentValues();
		initialValues.put(KEY_LOGIN, login);
		initialValues.put(KEY_PW, pw);
		initialValues.put(KEY_SIGNIN, signin ? 1 : 0);
		initialValues.put(KEY_SETTING_ID, settingId);
		initialValues.put(KEY_PRESENCE, presence);
		initialValues.put(KEY_STATUS, status);
		return db.insert(DATABASE_ACCOUNT_TABLE, null, initialValues);
	}

	/**
	 * Delete all records
	 * 
	 * @return
	 */
	public boolean deleteAllAccount() {
		return db.delete(DATABASE_ACCOUNT_TABLE, null, null) > 0;
	}

	/**
	 * Delete all records
	 * 
	 * @return
	 */
	public boolean deleteAccount(int id) {
		return db.delete(DATABASE_ACCOUNT_TABLE, "id=?",
				new String[] { id + "" }) > 0;
	}

	/**
	 * Get all data and return in a Cursor
	 * 
	 * @return Cursor
	 */
	public Cursor getAllAccount() {
		return db.query(DATABASE_ACCOUNT_TABLE, new String[] { KEY_ROWID,
				KEY_LOGIN, KEY_PW, KEY_SIGNIN, KEY_SETTING_ID, KEY_PRESENCE,
				KEY_STATUS }, null, null, null, null, null);
	}

	/**
	 * Update user account info
	 * 
	 * @param login
	 *            Email
	 * @param pw
	 *            Password in plain text
	 * @param signin
	 *            true = 1, false = 0. Indicates if the account is auto-sign-in
	 * @param settingId
	 *            Default = 0. Different XMPP servers have diff settings for
	 *            sign in. Users can also create custom sign in setting. Diff
	 *            settings are stored in db with a setting id.
	 * @param presence
	 *            1 = available, 0 = unavailable
	 * @param status
	 *            user's status message string
	 */
	public void update(String login, String pw, boolean signin, int settingId,
			int presence, String status) {
		ContentValues initialValues = new ContentValues();
		initialValues.put(KEY_LOGIN, login);
		initialValues.put(KEY_PW, pw);
		initialValues.put(KEY_SIGNIN, signin ? 1 : 0);
		initialValues.put(KEY_SETTING_ID, settingId);
		initialValues.put(KEY_PRESENCE, presence);
		initialValues.put(KEY_STATUS, status);
		db.update(DATABASE_ACCOUNT_TABLE, initialValues, "login=?",
				new String[] { login });
	}
}
