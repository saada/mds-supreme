package Mobi.UI;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import log.Log;

import org.jivesoftware.smack.XMPPException;

import Mobi.config.AppConfig;
import Mobi.config.MsgDict;
import Mobi.tree.*;
import Mobi.tree.MyAdapter.ViewHolder;
import Mobi.util.CS_FileTransfer;
import Mobi.util.TabletTCP;
import Mobi.xmpp.Entity;
import android.app.Activity;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CheckedTextView;
import android.widget.ExpandableListView.ExpandableListContextMenuInfo;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

public class MyFilesActivity extends Activity {
	
	Activity Othis = this;
	ListView myFiles;
	private boolean selected;
	protected TextView textView1;
	protected Button shareButton, downloadButton, openButton, selectAllButton, deleteButton, uploadButton;
	protected static Handler handler_;
	protected static MyAdapter fileListAdapter_;
	List<String> str_list =  new ArrayList<String>();
	List<String> name =  new ArrayList<String>();
	CS_FileTransfer csf;
	private Context c;
	Node nodeLocal = new Node(new Entity(null, "dir", "LOCAL FILES"));
	Node nodeVM = Global.VMFileNode;

	
    /** Called when the activity is first created. */
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);       
		final MyAdapter local_fileListAdapter_ = new MyAdapter(Othis,Global.LocalFileNode, 1);
		local_fileListAdapter_.ExpanderLevel(1);

		final MyAdapter vm_fileListAdapter_ = new MyAdapter(Othis, nodeVM, 1);

        
        selected = false;
        c = this; 
        setContentView(R.layout.myfile); 
        myFiles = (ListView) findViewById(R.id.bestList);

		fileListAdapter_ = new MyAdapter(this, Global.FileTreeRootNode, 0);		
		fileListAdapter_.ExpanderLevel(1);
		myFiles.setAdapter(fileListAdapter_);
		
        registerForContextMenu(myFiles);
        initializeHandler();
        
        uploadButton = (Button) findViewById(R.id.uploadButton);
        uploadButton.setOnClickListener(new OnClickListener()
        {
        	@Override
        	public void onClick(View v) {
				
        		str_list = local_fileListAdapter_.returnALLselectedPath(Global.LocalFileNode);
        		Log.i(str_list.toString());
				if(!str_list.isEmpty()){
				Global.MANAGER.RequestUploading(Global.MANAGER.getConn_().getUser(),
						Global.MANAGER.getConn_().getUser().split("/")[0],"",str_list);
				//NEED TO INSERT CODE TO UPDATE FILE LIST AFTER UPLOAD SUCCESSFUL
				} 
        	}        	
        });    
        
        downloadButton = (Button) findViewById(R.id.dButton);
        downloadButton.setOnClickListener(new OnClickListener()
        {
        	@Override
        	public void onClick(View v) {

        		str_list = local_fileListAdapter_.returnALLselectedPath(nodeVM);
				name = local_fileListAdapter_.returnALLselectedName(nodeVM);
        		Log.i(str_list.toString());
				if(!str_list.isEmpty()){
				Global.MANAGER.RequestDownloading(Global.MANAGER.getConn_().getUser(),
						Global.MANAGER.getConn_().getUser().split("/")[0],"",str_list, name);
				//NEED TO INSERT CODE TO UPDATE FILE LIST AFTER DOWNLOAD SUCCESSFUL

				}
        	}        	
        });
        
        openButton = (Button) findViewById(R.id.openButton);
        openButton.setOnClickListener(new OnClickListener()
        {

			@Override
			public void onClick(View arg0) {
				//OPEN (ONLY WORKS FOR LOCAL FILES)
				for(int i=1; i<fileListAdapter_.getCount(); i++)
				{
					try{
					LinearLayout ll = (LinearLayout) myFiles.getChildAt(i);
					LinearLayout ll2 = (LinearLayout) ll.getChildAt(1);
					TextView ctv = (TextView) ll2.getChildAt(0);
					CheckBox cb = (CheckBox) ll.getChildAt(2);
					if(cb.isChecked())
					{
						String filePath = "mnt/sdcard/MobiCloud/" + ctv.getText().toString();
						System.out.println(filePath);
						File file = new File(filePath);

						MimeTypeMap myMime = MimeTypeMap.getSingleton();

				        Intent newIntent = new Intent(android.content.Intent.ACTION_VIEW);
 
				        String mimeType = myMime.getMimeTypeFromExtension(fileExt(file.toString()).substring(1));
				        newIntent.setDataAndType(Uri.fromFile(file),mimeType);
				        newIntent.setFlags(newIntent.FLAG_ACTIVITY_NEW_TASK);
				        //tries to open file with appropriate installed program
				        try {
				            c.startActivity(newIntent);
				        }catch (android.content.ActivityNotFoundException e) {
				            Toast.makeText(c, "No handler for this type of file.", 4000).show();
				        }
					
					}
					} catch (Exception e)
					{
						System.out.println("*********" + e.toString());
						
					}

				}

			}
        	
        });
  
        selectAllButton = (Button) findViewById(R.id.saButton);
        selectAllButton.setOnClickListener(new OnClickListener()
        {
			@Override
			public void onClick(View v) {
				if(!selected)
				{
					fileListAdapter_.selectAllNode(true);	
				}
				else
				{
					fileListAdapter_.selectAllNode(false);
				}
			}
        	
        });	
        
        deleteButton = (Button) findViewById(R.id.delButton);
        deleteButton.setOnClickListener(new OnClickListener()
        { 
			@Override  
			public void onClick(View v) {

				for(int i=1; i<fileListAdapter_.getCount(); i++)
				{ 
					try{
					LinearLayout ll = (LinearLayout) myFiles.getChildAt(i);
					LinearLayout ll2 = (LinearLayout) ll.getChildAt(1);
					TextView ctv = (TextView) ll2.getChildAt(0);
					CheckBox cb = (CheckBox) ll.getChildAt(2);
					if(cb.isChecked())
					{ 
						String filePath = "/mnt/sdcard/MobiCloud/" + ctv.getText().toString();
						System.out.println(filePath);
						File file = new File(filePath);
						boolean deleted = file.delete();
					}
					} catch (Exception e)
					{
						System.out.println("*********" + e.toString());
						
					} 
				}
				
				Global.MANAGER.RequestFileListChange(
						fileListAdapter_.returnALLselectedID(Global.VMFileNode), 0);
				
				fileListAdapter_.deleteAllSelectedNode();
			}
        	
        }); 
    		
        shareButton = (Button) findViewById(R.id.shareButton);
        shareButton.setOnClickListener(new OnClickListener()
        {
			@Override
			public void onClick(View v) {
				//SHARE (can only make file more public)
	        	Bundle b = new Bundle();
				b.putString("whatToShare", "files");
	        	Intent shareDialog = new Intent(MyFilesActivity.this, GenericListActivity.class);
	        	shareDialog.putExtras(b);
	        	MyFilesActivity.this.startActivity(shareDialog); 
			}
        	
        });  
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        TextView t = new TextView(this);
        t.setText("filename.ext details\nShared with:\nLast modified:\nSize:");

        menu.setHeaderView(t);
        menu.add(0, 0, 0, "Open");
        menu.add(0, 1, 0, "Copy");
        menu.add(0, 2, 0, "Paste");
        menu.add(0, 3, 0, "Delete");
        menu.add(0, 4, 0, "Share");
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        ExpandableListContextMenuInfo info = (ExpandableListContextMenuInfo) item.getMenuInfo();

		if(item.getItemId() == 0)
        { 
        	//OPEN FILE
            Toast.makeText(this, "open file!", Toast.LENGTH_SHORT).show();
            return true;
        }
        if(item.getItemId() == 1)
        {
        	//DELETE FILE
        	Toast.makeText(this, "delete file!", Toast.LENGTH_SHORT).show();
        }

        return false;
    }
    
	private String fileExt(String url) {
	    String ext = url.substring(url.lastIndexOf(".") );
	    if (ext.indexOf("?")>-1) {
	        ext = ext.substring(0,ext.indexOf("?"));
	    }
	    if (ext.indexOf("%")>-1) {
	        ext = ext.substring(0,ext.indexOf("%"));
	    }
	    return ext;
	}
	
	private void initializeHandler() {
		handler_ = new Handler() {
			public void handleMessage(Message msg) {
				
				System.out.println("mess: " + msg);
				switch (msg.what) {				
				case MsgDict.FILETRANSFER_RECEIVED:{
								
					break;
				}

				case MsgDict.DOWNLOAD_REQUEST_SUCCESSFUL:
				{
					//updateFileTree();
					//fileListAdapter_.notifyDataSetChanged();
					
					Log.i("invoke begins");
					for(int i=0; i<str_list.size();i++){
						 try {
							csf = new CS_FileTransfer(Global.MANAGER.getConn_().getUser().split("@")[0]+".mobicloud.asu.edu",
									 6881,
									 str_list.get(i)+name.get(i));
							csf.invoke(true);
							//csf.close();
						} catch (IOException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}
						 Log.i("TabletTCP created");
						 //tt.run();
						 Log.i("TabletTCP started");
					}
					
					Context context = getApplicationContext();
					CharSequence text = "Download file request successful!";
					int duration = Toast.LENGTH_SHORT;

					Toast toast = Toast.makeText(context, text, duration);
					toast.show();
					
			 		break;
				}
				case MsgDict.DOWNLOAD_REQUEST_FAILED:
				{
					Context context = getApplicationContext();
					CharSequence text = "Download file request failed!";
					int duration = Toast.LENGTH_SHORT;

					Toast toast = Toast.makeText(context, text, duration);
					toast.show();

					break;
				}
				case MsgDict.UPLOAD_REQUEST_SUCCESSFUL:
				{
					//fileListAdapter_.notifyDataSetChanged();
					
					TabletTCP tt;
					for(String path :str_list){
						 tt = new TabletTCP(path, Global.MANAGER.getConn_().getUser().split("@")[0]+".mobicloud.asu.edu");
						 Log.i("TabletTCP created");
						 tt.run();
						 Log.i("TabletTCP started");
					}
					
					Context context = getApplicationContext();
					CharSequence text = "Upload file request successful!";
					int duration = Toast.LENGTH_SHORT;

					Toast toast = Toast.makeText(context, text, duration);
					toast.show();
					
					break;
				}
				case MsgDict.UPLOAD_REQUEST_FAILED:
				{
					Context context = getApplicationContext();
					CharSequence text = "Upload file request failed!";
					int duration = Toast.LENGTH_SHORT;

					Toast toast = Toast.makeText(context, text, duration);
					toast.show();
					
					break;  
				}
				case MsgDict.DELETE_REQUEST_SUCCESSFUL:{
					//fileListAdapter_.deleteAllSelectedNode();
					//fileListAdapter_.notifyDataSetChanged();  
					
					Context context = getApplicationContext();
					CharSequence text = "Delete request successful!";
					int duration = Toast.LENGTH_SHORT;

					Toast toast = Toast.makeText(context, text, duration);  
					//toast.show();
					break;
				}
				case MsgDict.DELETE_REQUEST_FAILED:{					
					Context context = getApplicationContext();
					CharSequence text = "Delete request failed!";
					int duration = Toast.LENGTH_SHORT;

					Toast toast = Toast.makeText(context, text, duration);
					//toast.show();
					
					break;
				}
				
			}
			
		}
		
	};
	}
	
	public static Handler getHandler() {
		return handler_;
	}

	public static void notifyHandler(int what, Object obj) {
		android.os.Message message = new android.os.Message();
		message.what = what;
		message.obj = obj;
		if (handler_ != null) {
			handler_.sendMessage(message);
		}
	}
	
	public void updateFileTree(){
		Global.MANAGER.getFileDir(Global.MANAGER.getRootPath(), Global.LocalFileNode);
		Global.FileTreeRootNode.clear();
		Global.FileTreeRootNode.add(Global.LocalFileNode);
		Global.FileTreeRootNode.add(Global.VMFileNode);
		myFiles.removeAllViewsInLayout();
		fileListAdapter_ = new MyAdapter(Othis, Global.FileTreeRootNode, 0);
		fileListAdapter_.ExpanderLevel(1);
		myFiles.setAdapter(fileListAdapter_);
	}

	private void getFileDir(String filePath, Node node) {
		File file = new File(filePath);
        File[] files = file.listFiles();
        for(File fileTemp :files) {
        	Node n;
        	if(fileTemp.isDirectory()){
        		n = new Node(new Entity(null, "dir", fileTemp.getName()));
        		node.add(n);
                n.setParent(node);
                getFileDir(fileTemp.getAbsolutePath(),n);
        	}
        	else if(fileTemp.isFile()){
        		Date date= new Date(fileTemp.lastModified());
        		n = new Node(new Entity(null,"file", fileTemp.getName(),fileTemp.length(),fileTemp.getAbsolutePath(),date,-1,null));
        		node.add(n);
                n.setParent(node);
        }       	
        }
	}
}

