package Mobi.UI;

import android.app.Dialog;
import android.content.Context;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.TextView;

public class StyledConfirmDialog {
	public static Dialog create(CharSequence title, CharSequence content,
			Context context) {
		Dialog dlg = new Dialog(context,
				android.R.style.Theme_Dialog);
		dlg.setCancelable(false);
		dlg.setContentView(R.layout.confirm_dialog);
//		((View) dlg.findViewById(R.id.confirm_bg))
//				.setBackgroundResource(R.drawable.dialog_bar_blue);
		((TextView) dlg.findViewById(R.id.confirm_title)).setText(title);
		((TextView) dlg.findViewById(R.id.confirm_content)).setText(content);
		return dlg;
	}

	public static void yesButton(final Dialog dialog, CharSequence text,
			OnClickListener listener) {
		Button btn = (Button) dialog.findViewById(R.id.confirm_yes);
		btn.setText(text);
		if (listener == null) {
			btn.setOnClickListener(new OnClickListener() {
				public void onClick(View v) {
					dialog.dismiss();
				}
			});
		} else {
			btn.setOnClickListener(listener);
		}
	}

	public static void noButton(final Dialog dialog, CharSequence text,
			OnClickListener listener) {
		Button btn = (Button) dialog.findViewById(R.id.confirm_no);
		btn.setText(text);
		if (listener == null) {
			btn.setOnClickListener(new OnClickListener() {
				public void onClick(View v) {
					dialog.dismiss();
				}
			});
		} else {
			btn.setOnClickListener(listener);
		}
	}
}
