package Mobi.UI;

import java.util.Collection; 

import org.jivesoftware.smack.Roster;
import org.jivesoftware.smack.RosterEntry;

import xmpp.Manager;
import Mobi.tree.MyAdapter;
import Mobi.tree.Node;
import Mobi.xmpp.Entity;
import Mobi.xmpp.Group;
import android.app.Application;
import android.content.res.Resources.Theme;

public class Global extends Application {
	
	public static Manager MANAGER;
	public static Roster roster;
	public static Collection <RosterEntry> allEntries;
	public static Object[] allEntriesArray;
	public static int numOfFriends;
	public static int theTheme = 0; //0 for black, 1 for light
	public static boolean themeChanged = false;
	
	public static Node FriendTreeRootNode = new Node(new Group("FRIENDS",false));
	public static Node FileTreeRootNode = new Node(new Group("MYFILES",false));
	public static Node VMFileNode;
	public static Node LocalFileNode;
	public static String LocalFileRootPath="/mnt/sdcard/MobiCloud";

	public static void changeTheme(String themeName)
	{

	}
	
	public static Entity f;
    

}
