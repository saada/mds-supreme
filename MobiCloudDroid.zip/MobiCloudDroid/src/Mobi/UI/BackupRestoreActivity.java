package Mobi.UI;


import log.Log; 
import Mobi.config.MsgDict;
import Mobi.tree.MyAdapter;
import Mobi.tree.Node;
import Mobi.xmpp.Entity;
import android.app.TabActivity; 
import android.content.Intent;
import android.content.res.Resources;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.widget.TabHost;

public class BackupRestoreActivity extends TabActivity {
    /** Called when the activity is first created. */
	
	protected static Handler handler_;
	protected MyAdapter fileListAdapter_; 
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	if(Global.theTheme == 1)
    		setTheme(android.R.style.Theme_Light);
    	
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        fileListAdapter_ = new MyAdapter(this, Global.FileTreeRootNode, 0);
        
        Resources res = getResources(); // Resource object to get Drawables
        TabHost tabHost = getTabHost();  // The activity TabHost
        TabHost.TabSpec spec;  // Resusable TabSpec for each tab
        Intent intent;  // Reusable Intent for each tab

        // Create an Intent to launch an Activity for the tab (to be reused)
        intent = new Intent().setClass(this, ContactsActivity.class);

        // Initialize CONTACTS tab
        spec = tabHost.newTabSpec("contacts").setIndicator("Contacts",
                          res.getDrawable(R.drawable.spacer))
                      .setContent(intent);
        tabHost.addTab(spec);

        // Initialize MYFILES tab
        intent = new Intent().setClass(this, MyFilesActivity.class);
        spec = tabHost.newTabSpec("myFiles").setIndicator("My Files",
                          res.getDrawable(R.drawable.spacer))
                      .setContent(intent);
        tabHost.addTab(spec);
        
        // Initialize SETTINGSS tab
        intent = new Intent().setClass(this, SettingsActivity.class);
        spec = tabHost.newTabSpec("settings").setIndicator("Settings",
                          res.getDrawable(R.drawable.spacer))
                      .setContent(intent);
        tabHost.addTab(spec);

        if(Global.themeChanged)
        {
    		Global.themeChanged = false;
    		tabHost.setCurrentTab(2);
        }
        else
    		tabHost.setCurrentTab(0);
    }
    public void onResume(Bundle savedInstanceState) {

    }
    
	/////////////////////////////////////
	/////// Handler Initialization //////
	/////////////////////////////////////
    private void initializeHandler() {
		handler_ = new Handler(this.getMainLooper()) {
			public void handleMessage(Message msg) {
				switch (msg.what) {
				case MsgDict.C_PRESENCE_CHANGED:{
					//updateView(AppConfig.STAGE_CONTACTS);
				}
					break;
				case MsgDict.CHAT_REQUEST:
					
					break;
					
				case MsgDict.FILELIST_UPDATE:{
					Global.VMFileNode = (Node) msg.obj;
					for(int i=0; i<Global.FileTreeRootNode.getChildren().size();i++){
						Node n = Global.FileTreeRootNode.getChildren().get(i);
						Entity tp = (Entity)n.getOb();
						if(tp.getE_name().equals("VMFILE")){
							fileListAdapter_.deleteNode(n);													
						}
					}									
					Global.FileTreeRootNode.add(Global.VMFileNode);
					
					fileListAdapter_.addNode(Global.VMFileNode);
					Log.i("add node successfully");
					break;
				}
				case MsgDict.DES_UPDATE:{

					break;
				}
				
				case MsgDict.USERPERMISSION_REQUEST_SUCCESSFUL:{
					Global.MANAGER.RequestFileList(Global.MANAGER.getConn_().getUser(),Global.MANAGER.getConn_().getUser().split("/")[0]+"/VM");					
					break;
				}
				case MsgDict.USERPERMISSION_REQUEST_FAILED:{
					
					break;
				}
				case MsgDict.DELETE_REQUEST_SUCCESSFUL:{
					fileListAdapter_.deleteAllSelectedNode();
					fileListAdapter_.notifyDataSetChanged();

					break;
				}
				case MsgDict.DELETE_REQUEST_FAILED:{					
	
					break;
				}
				case MsgDict.CREATEDIRECTORY_REQUEST_SUCCESSFUL:{
					break;
				}
				case MsgDict.CREATEDIRECTORY_REQUEST_FAILED:{
					break;
				}
				case MsgDict.RENAME_REQUEST_SUCCESSFUL:{
					break;
				}
				case MsgDict.RENAME_REQUEST_FAILED:{
					break;
				}				
				case MsgDict.SHARE_FILE_REQUEST:{					

					break;
				}
					
					
				}
			}
		};
		
	}
}