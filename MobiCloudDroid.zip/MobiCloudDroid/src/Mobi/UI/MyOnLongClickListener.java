/*package Mobi.UI;

import android.content.ClipData;
import android.content.ClipDescription;
import android.graphics.Color;
import android.view.View;
import android.view.View.DragShadowBuilder;

public class MyOnLongClickListener implements View.OnLongClickListener{
	int g_pos=-1;
	int c_pos;
	
	public MyOnLongClickListener(int x,int y) {
		super();
		g_pos = x;
		c_pos = y;
		// TODO Auto-generated constructor stub
	}
	
	public MyOnLongClickListener(int x) {
		super();
		c_pos = x;
		
		// TODO Auto-generated constructor stub
	}

	public boolean onLongClick(View v) {		
		
		String c_str = String.valueOf(c_pos);
		if(g_pos != -1){
			String g_str = String.valueOf(g_pos);
			ClipData.Item g_item = new ClipData.Item( (CharSequence) g_str);
			ClipData.Item c_item = new ClipData.Item( (CharSequence) c_str);
			ClipData dragData = new ClipData((CharSequence) v.getTag(), new String[] {ClipDescription.MIMETYPE_TEXT_PLAIN}, g_item);
			dragData.addItem(c_item);
			DragShadowBuilder myShadow = new MyDragShadowBuilder(v);
			
			v.startDrag(dragData,myShadow, null, 0 );
		}
		else{
			ClipData.Item c_item = new ClipData.Item( (CharSequence) c_str);
			ClipData dragData = new ClipData("temp clip for child "+c_pos, new String[] {ClipDescription.MIMETYPE_TEXT_PLAIN}, c_item);
			DragShadowBuilder myShadow = new MyDragShadowBuilder(v);
			
			v.startDrag(dragData,myShadow, null, 0 );
		}
		
		return true;
		
	}
}*/
