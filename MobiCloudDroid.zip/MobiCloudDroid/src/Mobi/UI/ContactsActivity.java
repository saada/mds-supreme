package Mobi.UI;

import org.jivesoftware.smack.RosterEntry; 
import org.jivesoftware.smack.packet.Presence;

import android.app.ExpandableListActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ContextMenu.ContextMenuInfo;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ArrayAdapter;
import android.widget.BaseExpandableListAdapter;
import android.widget.Button;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.ExpandableListView.ExpandableListContextMenuInfo;

public class ContactsActivity extends ExpandableListActivity {
ExpandableListAdapter myFriends;
	
	protected TextView textView1;
	protected int cp;
	protected int gp;
	String theChild;
	
    /** Called when the activity is first created. */
	@Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);       
        
        setContentView(R.layout.contacts);
          
        //get the current roster and stuff which we will use to build friend list
        Global.roster = Global.MANAGER.getXMPPConnection().getRoster();
        Global.allEntries = Global.roster.getEntries();
    	Global.numOfFriends = Global.roster.getEntryCount();
    	Global.allEntriesArray = new RosterEntry[Global.numOfFriends+1];
    	Global.allEntriesArray = Global.allEntries.toArray();
     
        //set up our adapter for the ExpandableList
        myFriends = new MyExpandableListAdapter();
        ((MyExpandableListAdapter) myFriends).fillFriendList();
        setListAdapter(myFriends);
        registerForContextMenu(getExpandableListView());
              
        //@Override
        (getExpandableListView()).setOnChildClickListener(new ExpandableListView.OnChildClickListener() {
            public boolean onChildClick(ExpandableListView parent,
                    View v, int groupPosition, int childPosition,
                    long id) {
            	cp = childPosition;
            	           
                return true;
            }
        });
    
    }

	//appears when user holds down a contact
    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenuInfo menuInfo) {
        if(Global.theTheme==1)
    		setTheme(android.R.style.Theme_Light);

    	menu.setHeaderTitle("Contact");
        menu.add(0, 0, 0, "Chat");
        menu.add(0, 1, 0, "View");

        ExpandableListView.ExpandableListContextMenuInfo info =
                (ExpandableListView.ExpandableListContextMenuInfo) menuInfo;
        theChild = ((TextView) info.targetView).getText().toString();
        cp = (int) info.id;
        
        
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        ExpandableListContextMenuInfo info = (ExpandableListContextMenuInfo) item.getMenuInfo();

		if(item.getItemId() == 0)
        {
        	//Open CHAT
        	Bundle b = new Bundle();
			b.putString("Jid", (String) theChild);      	
        	Intent chatDialog = new Intent(ContactsActivity.this, ChatActivity.class);
        	chatDialog.putExtras(b);
        	ContactsActivity.this.startActivity(chatDialog);		                
        }
        if(item.getItemId() == 1)
        {     	
        	//Go to contact's page
        	Bundle b = new Bundle();
			b.putString("contactName", (String) theChild);      		
			Intent viewContact = new Intent(ContactsActivity.this, ViewContactActivity.class);
        	viewContact.putExtras(b);
            ContactsActivity.this.startActivity(viewContact);
        	
        }
        return true;
        
    }
 
    public class MyExpandableListAdapter extends BaseExpandableListAdapter {
        private String[] tag; 
        private String[][] friends; 
        private int online = 0;
        private int offline = 0;
      
        public void fillFriendList() {
        	// determine the number of online/offline friends
        	for(int i=0; i<Global.numOfFriends; i++)
        	{
        		if( Global.roster.getPresence(((RosterEntry) Global.allEntriesArray[i]).getUser()).equals(Presence.Type.available))
        		{
        			online++;
        		}
        		else
        		{
        			offline++;
        		}
        	}
        	// create online/offline arrays using number of online/offline friends for size
            String[] onlinePpl = new String[online];
            String[] offlinePpl = new String[offline];
            int count = 0;
            //fill the online array with online friends!
        	for(int i=0; i<Global.numOfFriends; i++)
        	{
        		if( Global.roster.getPresence(((RosterEntry)Global.allEntriesArray[i]).getUser()).equals(Presence.Mode.available))
        		{
        			onlinePpl[count] = ((RosterEntry) Global.allEntriesArray[i]).getName();
        			count++;
        		}
        	}
        	count = 0;
        	//fill the offline array with offline friends!
        	for(int i=0; i<Global.numOfFriends; i++)
        	{
        		if( Global.roster.getPresence(((RosterEntry) Global.allEntriesArray[i]).getUser()).equals(Presence.Mode.available))
        		{
        			//skip
        		}
        		else
        		{
        			offlinePpl[count] = ((RosterEntry) Global.allEntriesArray[i]).getName();
        			count++;
        		}
        	}
        	//load friend list with online/offline arrays      	
        	tag = new String[]{ "     Online (" + online + ")" , "     Offline (" + offline + ")"};
        	friends = new String[][] { onlinePpl, offlinePpl};
        }

        public Object getChild(int groupPosition, int childPosition) {
            return friends[groupPosition][childPosition];
        }

        public long getChildId(int groupPosition, int childPosition) {
            return childPosition;
        }

        public int getChildrenCount(int groupPosition) {
            return friends[groupPosition].length;
        }

        public TextView getGenericView() {
            // Layout parameters for the ExpandableListView
            AbsListView.LayoutParams lp = new AbsListView.LayoutParams(
                    ViewGroup.LayoutParams.FILL_PARENT, 64);

            TextView textView = new TextView(ContactsActivity.this);
            textView.setLayoutParams(lp);
            // Center the text vertically
            textView.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT);
            // Set the text starting position
            textView.setPadding(36, 0, 0, 0);
            return textView;
        }

        public View getChildView(int groupPosition, int childPosition, boolean isLastChild,
                View convertView, ViewGroup parent) {
            TextView textView = getGenericView();
            textView.setText(getChild(groupPosition, childPosition).toString());
            return textView;
        }

        public Object getGroup(int groupPosition) {
            return tag[groupPosition];
        }

        public int getGroupCount() {
            return tag.length;
        }

        public long getGroupId(int groupPosition) {
            return groupPosition;
        }

        public View getGroupView(int groupPosition, boolean isExpanded, View convertView,
                ViewGroup parent) {
            TextView textView = getGenericView();
            textView.setText(getGroup(groupPosition).toString());
            return textView;
        }

        public boolean isChildSelectable(int groupPosition, int childPosition) {
            return true;
        }

        public boolean hasStableIds() {
            return true;
        }
    }
}


	
	