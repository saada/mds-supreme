package Mobi.UI;

import java.util.ArrayList;
import java.util.List;

import log.Log;

import org.jivesoftware.smack.RosterEntry;

import Mobi.config.MsgDict;
import Mobi.tree.MyAdapter;
import Mobi.tree.Node;
import Mobi.xmpp.Entity;
import Mobi.xmpp.Group;
import Mobi.xmpp.VMFile;
import android.app.Activity;
import android.app.Dialog;
import android.app.ListActivity;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckedTextView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;



public class GenericListActivity extends Activity {
	
	LinearLayout ll;
	Button share;
	Button selectAll;
	ListView lv;
	ArrayList<String> gList;
	private ArrayList<String> entity;
	private ArrayList<String> jid;
	ArrayAdapter<String> la;
	TextView title;
	private static Handler handler_;
    static String[] contactnames;
	protected static MyAdapter fileListAdapter_;
    
	@Override
	 public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
        setContentView(R.layout.share);
                     
        // Set the "list of lists"
        lv = (ListView) findViewById(R.id.list);
        
        registerForContextMenu(lv);

        
        // Customize listview (can display file list or contact list)
        Bundle b = this.getIntent().getExtras();
        String what =  b.getString("whatToShare");
        entity = b.getStringArrayList("theFilesToShare");
        gList = new ArrayList<String>();
        share = (Button)findViewById(R.id.sButton);
        selectAll = (Button)findViewById(R.id.saButton);
        title = (TextView)findViewById(R.id.textViewTitle);
        // Fill with files
        if(what.equals("files"))
        {
    		fileListAdapter_ = new MyAdapter(this, Global.FileTreeRootNode, 0);		
    		fileListAdapter_.ExpanderLevel(1);
    		lv.setAdapter(fileListAdapter_);
            lv = (ListView)findViewById(R.id.list);		
        }
        // Fill with contacts
        else
        {   
        	title.setText("Select one or more contacts to share with:");
        	share.setText("Finish");
        	contactnames = new String[Global.numOfFriends];  
        	//populate contactnames
	        for(int i=0; i<contactnames.length; i++)
	        {
	        	contactnames[i] = ((RosterEntry) Global.allEntriesArray[i]).getName().toString();
	        }      	
        	//populate list
	        for(int i=0; i<contactnames.length; i++)
	        {
	        	gList.add(contactnames[i]);
	        }  	
	        lv.setAdapter(la = new ArrayAdapter<String>(this, R.layout.list_item, R.id.label, gList));

	        //MESSAGING
	        initializeHandler();
        }
       
        lv.setTextFilterEnabled(true);    
        lv.setChoiceMode(ListView.CHOICE_MODE_MULTIPLE);
       
        ll = (LinearLayout) findViewById(R.id.groups);
		// THEME STUFF
        if(Global.theTheme == 1)
		{
        	ll.setBackgroundColor(Color.WHITE);
        	title.setTextColor(Color.BLACK);
        	for(int i=0; i<lv.getChildCount(); i++)
        	{
        		((CheckedTextView) lv.getChildAt(i)).setTextColor(Color.BLACK);   
        	}
		}
        
        lv.setOnItemClickListener(new OnItemClickListener() {   	
			@Override
			public void onItemClick(AdapterView<?> theList, View theView, int pos,
					long arg3) {
				// TODO Auto-generated method stub
				//View v = theList.getChildAt(pos);
		        CheckedTextView ctv = (CheckedTextView) theView; 
		        if(ctv.isChecked())
		        {
		        	ctv.setChecked(false);
		        }
		        else
		        {
		        	ctv.setChecked(true);
		        }
				
			}       	
        });
        
        selectAll.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				fileListAdapter_.selectAllNode(true);						
			}
        	
        });
        
        share.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				if(share.getText().equals("Next"))
				{					
					//Picked files, now let's go pick who to share them with!
		        	Bundle b = new Bundle();
					b.putString("whatToShare", "contacts");
					b.putStringArrayList("theFilesToShare", fileListAdapter_.returnALLselectedID(Global.FileTreeRootNode.getChildren().get(1)));
		        	Intent shareContactsDialog = new Intent(GenericListActivity.this, GenericListActivity.class);
		        	shareContactsDialog.putExtras(b);
		        	GenericListActivity.this.startActivity(shareContactsDialog); 
		        	finish();
				} 
				else
				{
					//We have files and we know who to share them with, send XMPP message
					jid = new ArrayList<String>();

					for(int i=0; i<lv.getCount(); i++)
					{
						CheckedTextView ctv = (CheckedTextView) lv.getChildAt(i);
						if(ctv.isChecked())
						{
							try{
								String s = ctv.getText().toString();
								jid.add(s); 
							} catch (Exception e)
							{
								System.out.println("----------" + e);
							}
						}
					}					
					Global.MANAGER.RequestPermissionChange( Global.MANAGER.getConn_().getUser(),
							Global.MANAGER.getConn_().getUser().split("/")[0]+"VM",
							entity, jid, MsgDict.SHARED	);

					
					finish();
				}
			}
        	
        });
        
        
    }
	
	// MESSAGING STUFF!!!!!!!!!!!!
	private void initializeHandler() {
		handler_ = new Handler(this.getMainLooper()) {
			public void handleMessage(Message msg) {
				switch (msg.what) {
				case MsgDict.C_PRESENCE_CHANGED:{
					//updateView(AppConfig.STAGE_CONTACTS);
				}
					break;
				case MsgDict.CHAT_REQUEST:
					
					break;
					
				case MsgDict.FILELIST_UPDATE:{
					Global.VMFileNode = (Node) msg.obj;
					for(int i=0; i<Global.FileTreeRootNode.getChildren().size();i++){
						Node n = Global.FileTreeRootNode.getChildren().get(i);
						Entity tp = (Entity)n.getOb();
						if(tp.getE_name().equals("VMFILE")){
							fileListAdapter_.deleteNode(n);													
						}
					}									
					Global.FileTreeRootNode.add(Global.VMFileNode);
					
					fileListAdapter_.addNode(Global.VMFileNode);
					//list.invalidate();
					Log.i("add node successfully");
					//updateView(AppConfig.STAGE_MYFILES);					
					break;
				}
				case MsgDict.DES_UPDATE:{
					/*f = (Entity) msg.obj;
					des.setVisibility(View.VISIBLE);
					filename.setText("FILE NAME: "+f.getE_name());
					filesize.setText("FILE SIZE: "+f.getE_size().toString()+" Byte");
					url.setText("Path: "+ f.getE_url());
					modifytime.setText("MODIFIED DATE: "+f.getE_modate().toString());
					sharewith.setText("SHARE WITH: " + f.getE_sharedBy().toString());
					*/
					break;
				}
				
				case MsgDict.USERPERMISSION_REQUEST_SUCCESSFUL:{
					//final int p = (Integer) msg.obj;
					Global.MANAGER.RequestFileList(Global.MANAGER.getConn_().getUser(),Global.MANAGER.getConn_().getUser().split("/")[0]+"/VM");					
					break;
				}
				case MsgDict.USERPERMISSION_REQUEST_FAILED:{
					
					break;
				}
				case MsgDict.DELETE_REQUEST_SUCCESSFUL:{
					fileListAdapter_.deleteAllSelectedNode();
					fileListAdapter_.notifyDataSetChanged();

					break;
				}
				case MsgDict.DELETE_REQUEST_FAILED:{					
	
					break;
				}

				case MsgDict.CREATEDIRECTORY_REQUEST_SUCCESSFUL:{
					break;
				}
				case MsgDict.CREATEDIRECTORY_REQUEST_FAILED:{
					break;
				}
				case MsgDict.RENAME_REQUEST_SUCCESSFUL:{
					break;
				}
				case MsgDict.RENAME_REQUEST_FAILED:{
					break;
				}
				
				case MsgDict.SHARE_FILE_REQUEST:{					

					break;
				}
					
					
				}
			}
		};
		
	}
	
	public static Handler getHandler() {
		return handler_;
	}

	public static void notifyHandler(int what, Object obj) {
		android.os.Message message = new android.os.Message();
		message.what = what;
		message.obj = obj;
		if (handler_ != null) {
			handler_.sendMessage(message);
		}
	}
}
