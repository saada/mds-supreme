package Mobi.UI;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextThemeWrapper;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemSelectedListener;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;

public class SettingsActivity extends Activity {
	
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        
        setContentView(R.layout.settings);
        
        Spinner theme = (Spinner) findViewById(R.id.spinnerTheme);
        ArrayAdapter<CharSequence> themeAdapter = ArrayAdapter.createFromResource(
                this, R.array.theme_array, android.R.layout.simple_spinner_item);
        themeAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        theme.setAdapter(themeAdapter);
        theme.setSelection(Global.theTheme);
        
        theme.setOnItemSelectedListener(new ThemeSelectedListener());
        
        EditText emailEditText = (EditText) findViewById(R.id.editTextEmail);
        //emailEditText.setText(Global.MANAGER.getEmail());
    	EditText usernameEditText = (EditText) findViewById(R.id.editTextUsername);
    	usernameEditText.setText(Global.MANAGER.getEmail());
    }
    
    public class ThemeSelectedListener implements OnItemSelectedListener{
    	
    	@Override
	    public void onItemSelected(AdapterView<?> parent,
	            View view, int pos, long id)
	    {
    		//CHANGES THEMES!!
    		if(pos==0)
    		{
    			if(Global.theTheme == 1)
    				Global.themeChanged = true;
    			Global.theTheme = 0;
    		}
    		else
    		{
    			if(Global.theTheme == 0)
    				Global.themeChanged = true;
    			Global.theTheme = 1;
    		}    		
    		
        	if(Global.themeChanged)
        	{
            	Intent newTabScreen = new Intent(SettingsActivity.this, BackupRestoreActivity.class);
            	SettingsActivity.this.startActivity(newTabScreen); 
            	finish();
        	}
    	}

		@Override
		public void onNothingSelected(AdapterView<?> arg0) {
			// do nothing			
		}
    }

}
