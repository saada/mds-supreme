/*package Mobi.UI;

import Mobi.tree.MyAdapter; 
import Mobi.tree.Node;
import Mobi.xmpp.Group;
import Mobi.xmpp.VMFile;
import android.content.ClipDescription;
import android.graphics.Color;
import androimport android.view.DragEvent;
import android.view.View;
import android.widget.Adapter;



public class MyFileDragEventListener implements View.OnDragListener {
	int g_pos = -1;
	int c_pos = -1;
	MyAdapter adapter;
	private CharSequence dragData;

	
	//public MyFileDragEventListener(MyExpandableFileListAdapter adapter, int groupPosition, int childPosition) {
		// TODO Auto-generated constructor stub
	//	g_pos = groupPosition;
	//	c_pos = childPosition;
	//	this.adapter = adapter;
	//}


	public MyFileDragEventListener(MyAdapter myAdapter, int position) {
		// TODO Auto-generated constructor stub
		c_pos = position;
		this.adapter = myAdapter;
	}

	public boolean onDrag(View v, DragEvent event) {
		final int action = event.getAction();
		if(g_pos != -1){				
		}
			else{
				switch(action) {
				case DragEvent.ACTION_DRAG_STARTED:
					Log.i(v.toString(),"drag start");
					v.setAlpha(20);					
					v.requestFocus();
					if (event.getClipDescription().hasMimeType(ClipDescription.MIMETYPE_TEXT_PLAIN)) {										
						v.invalidate();					
						return(true);
					} else {						                    
						return(false);                    
					}                
					
					
				case DragEvent.ACTION_DRAG_ENTERED:
					Log.i(v.toString(),"drag entered");
					if(c_pos!=-1){
						
					}
					else{	
						v.setBackgroundColor(Color.WHITE);
					}								
					v.invalidate();
					return (true); 
					
				case DragEvent.ACTION_DRAG_LOCATION:
					if(c_pos!=-1){
						
					}
					else{	
						
					}
					return true;
					
				case DragEvent.ACTION_DRAG_EXITED:
					Log.i(v.toString(),"drag exit");
					if(c_pos!=-1){
						
					}
					else{	
						v.setBackgroundColor(Color.TRANSPARENT);
					}
						
					v.invalidate();
					return true;
			
				case DragEvent.ACTION_DROP:			 
					//ClipData.Item item = event.getClipData().getItemAt(0);
					Log.i(v.toString(),"drag drop");
					//obtain dragged item's position
					int c= Integer.parseInt(event.getClipData().getItemAt(0).getText().toString());
					Node temp = (Node) adapter.getItem(c);
					Node local = (Node) adapter.getItem(c_pos);
					if(!(local.getOb().getClass().equals(Group.class))){					
						//View mDragView = (View) event.getLocalState();
						if(c>c_pos){
							adapter.removeNode(c, temp);
							adapter.addNode(c_pos+1, temp);							
						}
						else{
							adapter.removeNode(c, temp);
							adapter.addNode(c_pos, temp);
							
						}											
					}
					else{
						if(local.isExpanded){
							if(!local.getChildren().contains(temp)){																	
									adapter.removeNode(c, temp);
									adapter.addNode(c_pos+1, temp);								
							}							
						}
						else{
							adapter.removeNode(c, temp);
							local.add(temp);
							temp.setParent(local);
						}
						
					}
					adapter.notifyDataSetChanged();		
					
					v.invalidate();		 
					return true;		
				 
				case DragEvent.ACTION_DRAG_ENDED:
					Log.i(v.toString(),"drag end");
					v.setAlpha(100);
					v.invalidate();
	                   
					if (event.getResult()) {
					 //Toast.makeText(this, "The drop was handled.", Toast.LENGTH_LONG);
					} else {
					 //Toast.makeText(this, "The drop didn't work.", Toast.LENGTH_LONG);
					};
					 return true ;				
			 	default:
			 		//Log.e("DragDrop Example","Unknown action type received by OnDragListener.");
			 		break;		
				}
					return true;	
		}
		return true;
	}
}
*/

