package xmpp;

public class MsgDict {
	public final static int LOG = 0x0000;

	public final static int SHARE_FILE_REQUEST = 0x1000;
	public final static int SHARE_FILE_ACCEPTED = 0x1003;
	public final static int SHARE_FILE_REJECTED = 0x1004;
	public final static int SHARE_FILE_VM_SEND_START = 0x1010;
	public final static int SHARE_FILE_VM_RECEIVE_START = 0x1011;
	public final static int SHARE_FILE_VM_SEND_ENCRYPT_CODE = 0x1012;
	public final static int SHARE_FILE_COMPLETE = 0x1020;
	public final static int SHARE_FILE_UPLOAD_AFTER_COMPLETE = 0x1021;
}
