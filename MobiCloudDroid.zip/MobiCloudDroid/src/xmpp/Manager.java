package xmpp;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import log.Log;

import org.jivesoftware.smack.Chat;
import org.jivesoftware.smack.ChatManager;
import org.jivesoftware.smack.ChatManagerListener;
import org.jivesoftware.smack.ConnectionConfiguration;
import org.jivesoftware.smack.ConnectionListener;
import org.jivesoftware.smack.MessageListener;
import org.jivesoftware.smack.PacketListener;
import org.jivesoftware.smack.Roster;
import org.jivesoftware.smack.RosterEntry;
import org.jivesoftware.smack.RosterGroup;
import org.jivesoftware.smack.RosterListener;
import org.jivesoftware.smack.SmackConfiguration;
import org.jivesoftware.smack.XMPPConnection;
import org.jivesoftware.smack.XMPPException;
import org.jivesoftware.smack.filter.PacketTypeFilter;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Message.Type;
import org.jivesoftware.smack.packet.Packet;
import org.jivesoftware.smack.packet.Presence;
import org.jivesoftware.smack.provider.PrivacyProvider;
import org.jivesoftware.smack.provider.ProviderManager;
import org.jivesoftware.smack.util.Base64.OutputStream;
import org.jivesoftware.smackx.GroupChatInvitation;
import org.jivesoftware.smackx.OfflineMessageManager;
import org.jivesoftware.smackx.PrivateDataManager;
import org.jivesoftware.smackx.filetransfer.FileTransferListener;
import org.jivesoftware.smackx.filetransfer.FileTransferManager;
import org.jivesoftware.smackx.filetransfer.FileTransferRequest;
import org.jivesoftware.smackx.filetransfer.IncomingFileTransfer;
import org.jivesoftware.smackx.filetransfer.OutgoingFileTransfer;
import org.jivesoftware.smackx.packet.ChatStateExtension;
import org.jivesoftware.smackx.packet.LastActivity;
import org.jivesoftware.smackx.packet.OfflineMessageInfo;
import org.jivesoftware.smackx.packet.OfflineMessageRequest;
import org.jivesoftware.smackx.packet.SharedGroupsInfo;
import org.jivesoftware.smackx.provider.AdHocCommandDataProvider;
import org.jivesoftware.smackx.provider.BytestreamsProvider;
import org.jivesoftware.smackx.provider.DataFormProvider;
import org.jivesoftware.smackx.provider.DelayInformationProvider;
import org.jivesoftware.smackx.provider.DiscoverInfoProvider;
import org.jivesoftware.smackx.provider.DiscoverItemsProvider;
import org.jivesoftware.smackx.provider.IBBProviders;
import org.jivesoftware.smackx.provider.MUCAdminProvider;
import org.jivesoftware.smackx.provider.MUCOwnerProvider;
import org.jivesoftware.smackx.provider.MUCUserProvider;
import org.jivesoftware.smackx.provider.MessageEventProvider;
import org.jivesoftware.smackx.provider.MultipleAddressesProvider;
import org.jivesoftware.smackx.provider.RosterExchangeProvider;
import org.jivesoftware.smackx.provider.StreamInitiationProvider;
import org.jivesoftware.smackx.provider.VCardProvider;
import org.jivesoftware.smackx.provider.XHTMLExtensionProvider;
import org.jivesoftware.smackx.search.UserSearch;





import Mobi.UI.Global;
import Mobi.UI.MobiCloudDroidActivity;
import Mobi.config.MsgDict;
import Mobi.tree.Node;
import Mobi.util.MsgProtocal;
import Mobi.xmpp.Entity;
import Mobi.xmpp.Group;
import Mobi.xmpp.User;

public class Manager  {
	// =================================================================
	// Fields
	// =================================================================
	private String email_;
	private String pw_;
	private int id_;
	private boolean signIn_;
	private int settingId_;
	private Presence.Type presence_;
	private String status_;
	private ConnectionConfiguration XMPPConfig_;
	private XMPPConnection conn_;
	public XMPPConnection getConn_() {
		return conn_;
	}

	public void setConn_(XMPPConnection conn_) {
		this.conn_ = conn_;
	}

	private FileTransferManager fileTransferManager_;
	private ChatManager chatManager_;
	private Chat chat;
	private MessageHandler handler_;
	private String rootPath = Global.LocalFileRootPath;

	public String getRootPath() {
		return rootPath;
	}
	
	// =================================================================
	// Functions
	// =================================================================
	/**
	 * Create an XMPP connection manager
	 * 
	 * @param id
	 *            user id
	 * @param email
	 *            user login email
	 * @param pw
	 *            user login password
	 * @param signIn
	 *            auto sign in? (not used)
	 * @param settingId
	 *            which connection config to use from XMPPConnectionConfig class
	 */
	public Manager(int id, String email, String pw, boolean signIn,
			int settingId, int presence, String status) {
		email_ = email;
		pw_ = pw;
		signIn_ = signIn;
		settingId_ = settingId;
		id_ = id;
		presence_ = (presence == 1) ? Presence.Type.available
				: Presence.Type.unavailable;
		status_ = status;
		XMPPConfig_ = XMPPConnectionConfig.getXMPPConnectionConfig(settingId_);
		XMPPConfig_.setSendPresence(false); 
		chatManager_= null;
		configure(ProviderManager.getInstance());
		XMPPConnection.DEBUG_ENABLED = true;
		conn_ = new XMPPConnection(XMPPConfig_);
		fileTransferManager_ = new FileTransferManager(conn_);
		SmackConfiguration.setPacketReplyTimeout(15000);


	}

	/**
	 * Login to XMPP Server
	 */
	public boolean login() { 
		try {
			conn_.connect();
			if (conn_.isConnected()) {
				Log.i("Connected to server.");				
				conn_.login(email_, pw_, "GoogleTV");
				
				if (conn_.isAuthenticated()) {
					Log.i("Logged in.");
					// Send presence to server
					FetchOfflineDate();
					Presence presence = new Presence(Presence.Type.available);
					presence.setStatus(status_);
					presence.setPriority(-1);
					presence.setMode(Presence.Mode.available);
					conn_.sendPacket(presence);
					// Start msg handler
					if (handler_ != null) {
						handler_.terminate();
					}
					handler_ = new MessageHandler();
					handler_.addAllow(conn_.getUser().split("/")[0]);
					handler_.start();

					// Add Connection Listener for exception handling
					conn_.addConnectionListener(new ConnectionListener() {
						//@Override
						public void connectionClosed() {
							// login();
							System.out.println("connectionClosed");
						}

						//@Override
						public void connectionClosedOnError(Exception e) {
							// login();
							System.out.println("connectionClosedOnError");
						}

						//@Override
						public void reconnectingIn(int seconds) {
						}

						//@Override
						public void reconnectionFailed(Exception e) {
							// login();
							Log.i("reconnectionFailed");
						}

						//@Override
						public void reconnectionSuccessful() {
							Log.i("reconnectionSuccessful");
						}
					});

					// Get roster and set listener
					Global.roster = conn_.getRoster();
					Global.roster
							.setSubscriptionMode(Roster.SubscriptionMode.accept_all);
					Global.roster.addRosterListener(new RosterListener() {

						//@Override
						public void entriesAdded(Collection<String> addresses) {
						}

						public void entriesDeleted(Collection<String> addresses) {
						}

						public void entriesUpdated(Collection<String> addresses) {
						}
						//@Override
						public void presenceChanged(Presence presence) {
							//UpdateRosterTree();
							//MainActivity.notifyHandler(MsgDict.C_PRESENCE_CHANGED, null);
						}
					});
					
					//get the roster and build the in a local tree
					UpdateRosterTree();
					//Register the listener for detecting a chat from other clients
					RegisterChatReceiveListener();
					//Register the listener for detecting a sharing from other clients
					RegisterFileReceiveListener();	      
					
					//Get local file list
					String rootPath = "/mnt/sdcard/MobiCloud";
			    	Global.LocalFileNode = new Node(new Entity(null, "dir","LOCAL FILES"));
			        getFileDir(rootPath, Global.LocalFileNode);
			        Global.FileTreeRootNode.add(Global.LocalFileNode);
					
					
			      //Request VM file list
					RequestFileList(conn_.getUser(),conn_.getUser().split("/")[0]+"/VM");
					
					// Add package listener for message forwarding to
					// MainActivity
					
									
					PacketTypeFilter filter = new PacketTypeFilter(Message.class);
					conn_.addPacketListener(new PacketListener() {
						public void processPacket(Packet packet) {
							Message message = (Message) packet;							
							if (message.getType().equals(Type.normal)) {
								handler_.add(message);
								Log.i("Message received: " +
								 message.toXML());
							} else if (message.getType().equals(Type.chat)){
								// treat as normal chat
							}
						}
					}, filter);					
				}
			}
		} catch (Exception e) {
			Log.e(e);
			if (conn_.isConnected()) {
				conn_.disconnect();
			}
		}
		if(conn_.isConnected()){
			return true;
		}
		else{
			return false;
		}
	}

	

	private void FetchOfflineDate() {
		OfflineMessageManager offlineManager = new OfflineMessageManager(conn_);  
        try {  
            Iterator<org.jivesoftware.smack.packet.Message> it = offlineManager  
                    .getMessages();  
  
            System.out.println(offlineManager.supportsFlexibleRetrieval());  
            System.out.println("# of offline message: " + offlineManager.getMessageCount());  
  
              
            Map<String,ArrayList<Message>> offlineMsgs = new HashMap<String,ArrayList<Message>>();  
              
            while (it.hasNext()) {  
                org.jivesoftware.smack.packet.Message message = it.next();  
                System.out  
                        .println("offline message, Received from ��" + message.getFrom()  
                                + "�� message: " + message.getBody());  
                String fromUser = message.getFrom().split("/")[0];  
  
                if(offlineMsgs.containsKey(fromUser))  
                {  
                    offlineMsgs.get(fromUser).add(message);  
                }else{  
                    ArrayList<Message> temp = new ArrayList<Message>();  
                    temp.add(message);  
                    offlineMsgs.put(fromUser, temp);  
                }  
            }  
  
            //��������д���������Ϣ����......  
            Set<String> keys = offlineMsgs.keySet();  
            Iterator<String> offIt = keys.iterator();  
            while(offIt.hasNext())  
            {  
                String key = offIt.next();  
                ArrayList<Message> ms = offlineMsgs.get(key);  
//                TelFrame tel = new TelFrame(key);  
//                ChatFrameThread cft = new ChatFrameThread(key, null);  
//                cft.setTel(tel);  
//                cft.start();  
//                for (int i = 0; i < ms.size(); i++) {  
//                    tel.messageReceiveHandler(ms.get(i));  
//                }  
            }  
              
              
            offlineManager.deleteMessages();  
        } catch (Exception e) {  
            e.printStackTrace();  
        }  
		
	}
	
	public void RequestFileListChange(ArrayList<String> entity,int type){
		Message outMessage = new Message();
		outMessage.setType(Type.normal);
		outMessage.setFrom(conn_.getUser());
		outMessage.setTo(conn_.getUser().split("/")[0]+"/VM");
		switch(type){
			case 0:
			{
				outMessage.setBody(MsgProtocal.createRequestDelete(entity));
				break;
			}
			case 1:
			{
				break;
			}
			case 2:
			{
				outMessage.setBody(MsgProtocal.createRequestMove(entity.get(0),entity.get(1)));
				break;
			}
			case 3:
			{
				break;
			}
		}
		
		
		conn_.sendPacket(outMessage);
		Log.i("FileListChange Message sent");
	}

	public void RequestUploading(String from,String jid, String des, List<String> str_list) {
		Message outMessage = new Message();
		outMessage.setType(Type.normal);		
		outMessage.setBody(MsgProtocal.createPermissonUploading(jid, des, str_list));
		outMessage.setFrom(from);
		outMessage.setTo(conn_.getUser().split("/")[0]+"/VM");
		conn_.sendPacket(outMessage);
		Log.i("Uploading Request Message sent");
		
	}
	
	public void RequestDownloading(String from,String jid, String des, List<String> str_list, List<String> name){
		Message outMessage = new Message();
		outMessage.setType(Type.normal);		
		outMessage.setBody(MsgProtocal.createPermissonDownloading(jid, des, str_list, name));
		outMessage.setFrom(from);
		outMessage.setTo(conn_.getUser().split("/")[0]+"/VM");
		conn_.sendPacket(outMessage);
		Log.i("Downloading Request Message sent");
	}
	
	private void RegisterChatReceiveListener() {
		conn_.getChatManager().addChatListener(new ChatManagerListener(){
			
			public void chatCreated( Chat c,  boolean createdLocally)
		    {
				//Log.i("receive chat:"+c.getBody());
				if (!createdLocally)
				{
					Log.i("receive remote chat:");					
					MobiCloudDroidActivity.notifyHandler(MsgDict.CHAT_REQUEST, c.getParticipant());
					
		    		
				}
		    }
		  });
		
	}

	public void RequestFileList(String from, String to) {
		Message outMessage = new Message();
		outMessage.setType(Type.normal);
		
		outMessage.setBody(MsgProtocal.createRequestDirectoryMessage(from.split("/")[0]));
		outMessage.setFrom(from);
		outMessage.setTo(conn_.getUser().split("/")[0]+"/VM");
		conn_.sendPacket(outMessage);
		
	}
	
	public void RequestPermissionChange(String from, String to, ArrayList<String> entity, ArrayList<String> jid, int permission){
		Message outMessage = new Message();
		outMessage.setType(Type.normal);
		
		outMessage.setBody(MsgProtocal.createPermissonChangeMessage(entity, jid, permission));
		outMessage.setFrom(from);
		outMessage.setTo(conn_.getUser().split("/")[0]+"/VM");
		conn_.sendPacket(outMessage);
	} 

	public void getFileDir(String filePath, Node node) {
		File file = new File(filePath);
        File[] files = file.listFiles();
        for(File fileTemp :files) {
        	Node n;
        	if(fileTemp.isDirectory()){
        		n = new Node(new Entity(null, "dir", fileTemp.getName()));
        		node.add(n);
                n.setParent(node);
                getFileDir(fileTemp.getAbsolutePath(),n);
        	}
        	else if(fileTemp.isFile()){
        		Date date= new Date(fileTemp.lastModified());
        		n = new Node(new Entity(null,"file", fileTemp.getName(),
        				fileTemp.length(),fileTemp.getAbsolutePath(),date,-1, null));
        		node.add(n);
                n.setParent(node);
        }       	
        }
	}

	/**
	 * Logout from XMPP server
	 */
	public void logout() {
		if (conn_.isConnected()) {
			if (handler_ != null) {
				handler_.terminate();
			}
			conn_.disconnect();
		}
	}
	
	
	
	public void UpdateRosterTree(){
		if(!Global.FriendTreeRootNode.isLeaf()){
			Global.FriendTreeRootNode = new Node(new Group("FRIENDS",false));
		}
		Iterator<RosterEntry> i = Global.roster.getEntries().iterator();
		int k;
		while (i.hasNext()) {
			// Create user object
			RosterEntry rosterEntry = i.next();
			String name = rosterEntry.getName();
			String jid = rosterEntry.getUser();
			String status = Global.roster.getPresence(jid).isAvailable()?"ONLINE":"OFFLINE";
			System.out.println(jid+": "+status);
			Iterator<RosterGroup> g = rosterEntry.getGroups().iterator();
			while(g.hasNext()){
				RosterGroup rosterGroup = g.next();
				for(k=0; k<Global.FriendTreeRootNode.getChildren().size();k++ ){
					if(Global.FriendTreeRootNode.getTag(k).equals(rosterGroup.getName())){
    					Node f = new Node(new User(name, jid, status, false));
        				Global.FriendTreeRootNode.getChildren().get(k).add(f);
        				f.setParent(Global.FriendTreeRootNode.getChildren().get(k));
    					break;
    				}
				}
				if(k == Global.FriendTreeRootNode.getChildren().size()){
    				Node g_node =new Node(new Group(rosterGroup.getName(),false));
					Global.FriendTreeRootNode.add(g_node);
					g_node.setParent(Global.FriendTreeRootNode);
					Node f = new Node(new User(name, jid, status, false));
	    			Global.FriendTreeRootNode.getChildren().get(k).add(f);
	    			f.setParent(Global.FriendTreeRootNode.getChildren().get(k));
				}
			}
			/*User user = connEntry.getUser(rosterEntry.getUser());
			
			if (user == null) {
				user = new User();
				if (rosterEntry.getName() == null
						|| rosterEntry.getName().equals("")) {
					user.setDispName(rosterEntry.getUser().split("@")[0]);
				} else {
					user.setDispName(rosterEntry.getName());
				}
				user.setAccountId(connEntry.getId());
				user.setJid(rosterEntry.getUser());
				user.setOwnerConnEntry(connEntry);
				connEntry.addUser(user);
			}
			Presence presence = Global.roster.getPresence(user.getJid());
			user.setOnline(presence.isAvailable());
			user.setMode(presence.getMode());
			user.setStatus(presence.getStatus());*/
		}
	}
	
	
		
	
	public void sendMessage(String message, String to, MessageListener listener) {
		
		chat = conn_.getChatManager().createChat(to, listener);
		try {
			chat.sendMessage(message);
		} catch(XMPPException e) {
			e.printStackTrace();
		}
	}
	
	private void RegisterFileReceiveListener() {
		fileTransferManager_.addFileTransferListener(new FileTransferListener() {
            public void fileTransferRequest(FileTransferRequest request) {
                  // Check to see if the request should be accepted
            	System.out.println("FileTransferListener starts!");
                  if(shouldAccept(request)) {
                        // Accept it
                        IncomingFileTransfer transfer = request.accept();
                        try {
                        	//Log.i(request.getFileName().split("/")[4]);
							transfer.recieveFile(new File("/mnt/sdcard/MobiCloud/"+"sendTest1.txt"));
						} catch (XMPPException e) {										
							e.printStackTrace();
						}
                  } else {
                        // Reject it
                        request.reject();
                  }
                System.out.println("FileTransferListener ends!");
            }
            
            private boolean shouldAccept(FileTransferRequest request) {
        		// TODO Auto-generated method stub
        		return true;
        	}
      });
		
	}
	
	public void fileTransfer(String file, String destination) throws XMPPException, IOException {
			//file = "/mnt/sdcard/MobiCloud/SOPHIE'S_WORLD.txt";
			destination = "xin@mobicloud-mds-mysqlserver/VM";
			OutputStream out = null;
			FileInputStream in = null;
		
	     	try {
	     			// Create the outgoing file transfer with qualifier (i.e / clientname)
	     		
	                OutgoingFileTransfer transfer = fileTransferManager_.createOutgoingFileTransfer(destination);                                                                            // Opens a file selection dialog
	                  
	                File sf = new File(file);
	                Log.i(sf.getName());
	                long fileSize = sf.length();
	                
	                if (file != null) {
	                    
						try {
	                        // output is an OutputStream declared as a global variable.
	                        /* Note that transfer.sendFile(fileName, fileSize, description);
	                        returns an OutputStream */
	                     out =  (OutputStream) transfer.sendFile
	                                (file, fileSize, "");
	                        //This is an InputStream declared as a global variable.
	                     in = new FileInputStream(sf);
	                        
	                        int i;                          
	                            while((i = in.read())!= -1){                                   
	                                out.write((byte)i);
	                            }                                                                                
	                     } catch (FileNotFoundException e1) {
	                            // TODO Auto-generated catch block
	                            e1.printStackTrace();
	                        }   
	                        //Close the streams when finished
	                        in.close();
	                        out.close();                                                                                
	                }
	            } catch (Exception e) {
	                // TODO Auto-generated catch block
	                System.out.println("@@@@@@@@@@@@@" + e);
	            }
	}
	
	
	


	/**
	 * Initialize the XMPP configuration
	 * 
	 * @param pm
	 */
	private void configure(ProviderManager pm) {
		// Private Data Storage
		pm.addIQProvider("query", "jabber:iq:private",
				new PrivateDataManager.PrivateDataIQProvider());

		// Time
		try {
			pm.addIQProvider("query", "jabber:iq:time", Class
					.forName("org.jivesoftware.smackx.packet.Time"));
		} catch (ClassNotFoundException e) {
			Log.e("Can't load class for org.jivesoftware.smackx.packet.Time");
		}

		// Roster Exchange
		pm.addExtensionProvider("x", "jabber:x:roster",
				new RosterExchangeProvider());

		// Message Events
		pm.addExtensionProvider("x", "jabber:x:event",
				new MessageEventProvider());

		// Chat State
		pm.addExtensionProvider("active",
				"http://jabber.org/protocol/chatstates",
				new ChatStateExtension.Provider());

		pm.addExtensionProvider("composing",
				"http://jabber.org/protocol/chatstates",
				new ChatStateExtension.Provider());

		pm.addExtensionProvider("paused",
				"http://jabber.org/protocol/chatstates",
				new ChatStateExtension.Provider());

		pm.addExtensionProvider("inactive",
				"http://jabber.org/protocol/chatstates",
				new ChatStateExtension.Provider());

		pm.addExtensionProvider("gone",
				"http://jabber.org/protocol/chatstates",
				new ChatStateExtension.Provider());

		// XHTML
		pm.addExtensionProvider("html", "http://jabber.org/protocol/xhtml-im",
				new XHTMLExtensionProvider());

		// Group Chat Invitations
		pm.addExtensionProvider("x", "jabber:x:conference",
				new GroupChatInvitation.Provider());

		// Service Discovery # Items
		pm.addIQProvider("query", "http://jabber.org/protocol/disco#items",
				new DiscoverItemsProvider());

		// Service Discovery # Info
		pm.addIQProvider("query", "http://jabber.org/protocol/disco#info",
				new DiscoverInfoProvider());

		// Data Forms
		pm.addExtensionProvider("x", "jabber:x:data", new DataFormProvider());

		// MUC User
		pm.addExtensionProvider("x", "http://jabber.org/protocol/muc#user",
				new MUCUserProvider());

		// MUC Admin
		pm.addIQProvider("query", "http://jabber.org/protocol/muc#admin",
				new MUCAdminProvider());

		// MUC Owner
		pm.addIQProvider("query", "http://jabber.org/protocol/muc#owner",
				new MUCOwnerProvider());

		// Delayed Delivery
		pm.addExtensionProvider("x", "jabber:x:delay",
				new DelayInformationProvider());

		// Version
		try {
			pm.addIQProvider("query", "jabber:iq:version", Class
					.forName("org.jivesoftware.smackx.packet.Version"));
		} catch (ClassNotFoundException e) {
			// Not sure what's happening here.
		}

		// VCard
		pm.addIQProvider("vCard", "vcard-temp", new VCardProvider());

		// Offline Message Requests
		pm.addIQProvider("offline", "http://jabber.org/protocol/offline",
				new OfflineMessageRequest.Provider());

		// Offline Message Indicator
		pm.addExtensionProvider("offline",
				"http://jabber.org/protocol/offline",
				new OfflineMessageInfo.Provider());

		// Last Activity
		pm
				.addIQProvider("query", "jabber:iq:last",
						new LastActivity.Provider());

		// User Search
		pm
				.addIQProvider("query", "jabber:iq:search",
						new UserSearch.Provider());

		// SharedGroupsInfo
		pm.addIQProvider("sharedgroup",
				"http://www.jivesoftware.org/protocol/sharedgroup",
				new SharedGroupsInfo.Provider());

		// JEP-33: Extended Stanza Addressing
		pm.addExtensionProvider("addresses",
				"http://jabber.org/protocol/address",
				new MultipleAddressesProvider());

		// FileTransfer
		pm.addIQProvider("si", "http://jabber.org/protocol/si",
				new StreamInitiationProvider());

		pm.addIQProvider("query", "http://jabber.org/protocol/bytestreams",
				new BytestreamsProvider());

		pm.addIQProvider("open", "http://jabber.org/protocol/ibb",
				new IBBProviders.Open());

		pm.addIQProvider("close", "http://jabber.org/protocol/ibb",
				new IBBProviders.Close());

		pm.addExtensionProvider("data", "http://jabber.org/protocol/ibb",
				new IBBProviders.Data());

		// Privacy
		pm.addIQProvider("query", "jabber:iq:privacy", new PrivacyProvider());

		pm.addIQProvider("command", "http://jabber.org/protocol/commands",
				new AdHocCommandDataProvider());
		pm.addExtensionProvider("malformed-action",
				"http://jabber.org/protocol/commands",
				new AdHocCommandDataProvider.MalformedActionError());
		pm.addExtensionProvider("bad-locale",
				"http://jabber.org/protocol/commands",
				new AdHocCommandDataProvider.BadLocaleError());
		pm.addExtensionProvider("bad-payload",
				"http://jabber.org/protocol/commands",
				new AdHocCommandDataProvider.BadPayloadError());
		pm.addExtensionProvider("bad-sessionid",
				"http://jabber.org/protocol/commands",
				new AdHocCommandDataProvider.BadSessionIDError());
		pm.addExtensionProvider("session-expired",
				"http://jabber.org/protocol/commands",
				new AdHocCommandDataProvider.SessionExpiredError());
	}

	// =================================================================
	// Getters and Setters
	// =================================================================
	public void setFileTransferManager(FileTransferManager m) {
		fileTransferManager_ = m;
	}

	public FileTransferManager getFileTransferManager() {
		return fileTransferManager_;
	}

	public void setEmail(String email) {
		this.email_ = email;
	}

	public String getEmail() {
		return email_;
	}

	public void setPw(String pw) {
		this.pw_ = pw;
	}

	public String getPw() {
		return pw_;
	}

	public void setId(int id) {
		this.id_ = id;
	}

	public int getId() {
		return id_;
	}

	public void setSignIn(boolean signIn) {
		this.signIn_ = signIn;
	}

	public boolean isSignIn() {
		return signIn_;
	}

	public void setXMPPConnection(XMPPConnection xMPPConnection) {
		conn_ = xMPPConnection;
	}

	public XMPPConnection getXMPPConnection() {
		return conn_;
	}

	public int getSettingId() {
		return settingId_;
	}

	public void setSettingId(int settingId) {
		this.settingId_ = settingId;
	}

	public ConnectionConfiguration getXMPPConfig() {
		return XMPPConfig_;
	}

	public void setXMPPConfig(ConnectionConfiguration xMPPConfig) {
		XMPPConfig_ = xMPPConfig;
	}

	public void setPresence(Presence.Type presence_) {
		this.presence_ = presence_;
	}

	public Presence.Type getPresence() {
		return presence_;
	}

	public void setStatus(String status_) {
		this.status_ = status_;
	}

	public String getStatus() {
		return status_;
	}

	public void processMessage(Chat arg0, Message arg1) {
		// TODO Auto-generated method stub
		
	}

}
