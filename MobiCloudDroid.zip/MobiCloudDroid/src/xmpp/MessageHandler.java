package xmpp;

import java.io.IOException;
import java.util.Hashtable;
import java.util.LinkedList;
import javax.xml.parsers.ParserConfigurationException;
import log.Log;
import org.jivesoftware.smack.packet.Message;
import org.jivesoftware.smack.packet.Packet;
import org.xml.sax.SAXException;

import Mobi.UI.Global;
import Mobi.UI.MobiCloudDroidActivity;
import Mobi.UI.MyFilesActivity;
import Mobi.config.MsgDict;
import Mobi.tree.Node;
import Mobi.util.Serialization;
import Mobi.util.XMLParser;
import Mobi.xmpp.Entity;


public class MessageHandler extends Thread  {
	private boolean isRunning_;
	private LinkedList<Packet> msgs_;
	private Hashtable<String, Boolean> allowList_;

	public MessageHandler() {
		msgs_ = new LinkedList<Packet>();
		allowList_ = new Hashtable<String, Boolean>();
		setDaemon(false);
	}

	public void addAllow(String jid) {
		synchronized (allowList_) {
			allowList_.put(jid, new Boolean(true));
		}
	}

	public void removeAllow(String jid) {
		synchronized (allowList_) {
			allowList_.remove(jid);
		}
	}

	public boolean checkAllow(String jid) {
		synchronized (allowList_) {
			return (allowList_.get(jid) != null);
		}
	}

	public void run() {
		isRunning_ = true;
		Packet msg = null;
		while (isRunning_) {
			synchronized (msgs_) {
				while (isRunning_ && (msg = msgs_.poll()) == null) {
					try {
						msgs_.wait(1000);
					} catch (Exception e) {
						e.printStackTrace();
					}
				}
			}
			System.out.println("stoppppppppppppp");
			if (isRunning_) {
				try {
					String fromJID = msg.getFrom().split("/")[0];
					//if (checkAllow(fromJID)) {
						// Log.i("Allowed " + fromJID +
						// " to perform doWork()...");
						doWork(msg);
					//} else {
						// Log.i("Disallowed " + fromJID + ", Bye!");
					//}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
	}

	public void doWork(Packet p) {
		// Log.i("DoWork: " + ((Message) p).getBody());
		XMLParser parser;
		try {
			parser = new XMLParser(((Message) p).getBody());
			Msg[] msgs = parser.getMsgList();
			for(Msg msg : msgs){
				if (msg != null){
					switch (msg.type) {
					case MsgDict.DELETE_REQUEST_SUCCESSFUL:{
						MyFilesActivity.notifyHandler(MsgDict.DELETE_REQUEST_SUCCESSFUL, null);
						break;
					}
					case MsgDict.DELETE_REQUEST_FAILED:{
						MyFilesActivity.notifyHandler(MsgDict.DELETE_REQUEST_FAILED, null);
						break;
					}
					case MsgDict.UPLOAD_REQUEST_FAILED:
					{
						MyFilesActivity.notifyHandler(MsgDict.UPLOAD_REQUEST_SUCCESSFUL, null);
						break;
					}
					case MsgDict.UPLOAD_REQUEST_SUCCESSFUL:
					{
						MyFilesActivity.notifyHandler(MsgDict.UPLOAD_REQUEST_SUCCESSFUL, null);
						break;
					}
					
					case MsgDict.DOWNLOAD_REQUEST_SUCCESSFUL:{
						MyFilesActivity.notifyHandler(MsgDict.DOWNLOAD_REQUEST_SUCCESSFUL, null);
						break;
					}
					
					case MsgDict.DOWNLOAD_REQUEST_FAILED:{
						MyFilesActivity.notifyHandler(MsgDict.DOWNLOAD_REQUEST_FAILED, null);
						break;
					}
					
					case MsgDict.FILELIST_UPDATE:{
						try {
							Log.i(msg.getAtr("jid")+" compare "+Global.MANAGER.getConn_().getUser());
							//if(msg.getAtr("jid").equals(Global.MANAGER.getConn_().getUser().split("/")[0])){
								Log.i(msg.getData(0));
//								for(int i=0; i<Global.FileTreeRootNode.getChildren().size();i++){
//									Entity tp = (Entity)Global.FileTreeRootNode.getChildren().get(i).getOb();
//									if(tp.getE_name().equals("VMFILE")){
//										Global.FileTreeRootNode.getChildren().remove(i);//										
//									}
//								}
								System.out.println("stringgggggggggggggggggg 1");
								System.out.print(msg);								
//								Global.FileTreeRootNode.add(temp);
								//System.out.println("stringgggggggggggggggggg 2");
								System.out.println("*********" + ((Entity)((Node) Serialization.fromString(msg.getData(0))).getOb()).e_name);
								MobiCloudDroidActivity.notifyHandler(MsgDict.FILELIST_UPDATE, Serialization.fromString(msg.getData(0)));
							//}						
						} catch (ClassNotFoundException e) {							
							e.printStackTrace();
						}
					}
					break;
					case MsgDict.SHARE_FILE_REQUEST:{
						
					}
					break;
//					case MsgDict.SHARE_FILE_VM_SEND_START: {
//						// 0: JID to send file to; 1:filename;
//						String jid = msg.getData(0);
//						String fileName = "cipher.tar.gz";// = msg.getData(1);
//						// addAllow(jid);
//						try {
//							Log.i("Starting sharing file with " + jid + " in 3 seconds.");
//							sleep(3000);
//							OutgoingFileTransfer transfer = Global.MANAGER.getFileTransferManager().createOutgoingFileTransfer(jid);
//								
//							int oldProgress = -1;
//							transfer.sendFile(new File(fileName), "Share file");
//							while (!transfer.isDone()) {
//								int newProgress = (int) (transfer.getProgress() * 100);
//								if (newProgress != oldProgress) {
//									Log.i("Sharing file '" + fileName + "' : "
//											+ newProgress + "%");
//								}
//								if (newProgress == 100) {
//									transfer.cancel();
//									break;
//								}
//								try {
//									Thread.sleep(100);
//								} catch (InterruptedException e) {
//									e.printStackTrace();
//								}
//							}
//						} catch (Exception e) {
//							e.printStackTrace();
//						}
	//
//					}
//						break;
//					case MsgDict.SHARE_FILE_VM_SEND_ENCRYPT_CODE: {
//						String encryptionCode = msg.getData(0);
//						try {
//							String cmd = "./encrypt_file pub.key " + encryptionCode;
//							ProcessBuilder pb = new ProcessBuilder("bash", "-c", cmd);
//							pb.redirectErrorStream(true);
//							Process shell = pb.start();
//							InputStream shellIn = shell.getInputStream();
//							int shellExitStatus = shell.waitFor();
//							int c;
//							while ((c = shellIn.read()) != -1) {
//								System.out.write(c);
//							}
//							shellIn.close();
//							Log.i("File encrypted.");
//						} catch (Exception e) {
//							e.printStackTrace();
//						}
//					}
//						break;
//					case MsgDict.SHARE_FILE_VM_RECEIVE_START: {
//						// 0: JID to receive file from; 1:filename;
//						String jid = msg.getData(0);
//						String fileName = msg.getData(1);
//						addAllow(jid.split("/")[0]);
//						Log.i("Authorizing " + jid + " to share file...");
//						Log.i("Waiting for " + jid + " to share file...");
//					}
//						break;
//					case MsgDict.SHARE_FILE_UPLOAD_AFTER_COMPLETE: {
//						// 0: JID the shared file owner jid; 1:filename;
//						String jid = msg.getData(0);
//						String fileName = msg.getData(1);
//						removeAllow(jid.split("/")[0]);
//						OutgoingFileTransfer transfer = Global.MANAGER
//								.getFileTransferManager().createOutgoingFileTransfer(
//										Global.MANAGER.getXMPPConnection().getUser()
//												.split("/")[0]
//												+ "/android");
//						Log.i("Starting uploading file to mobile phone...");
//						try {
//							int oldProgress = -1;
//							transfer.sendFile(new File(fileName), "Upload file");
//							while (!transfer.isDone()) {
//								int newProgress = (int) (transfer.getProgress() * 100);
//								if (newProgress != oldProgress) {
//									Log.i("Uploading file '" + fileName + "':"
//											+ newProgress + "%");
//								}
//								if (newProgress == 100) {
//									transfer.cancel();
//									break;
//								}
//								try {
//									Thread.sleep(100);
//								} catch (InterruptedException e) {
//									e.printStackTrace();
//								}
//							}
//						} catch (Exception e) {
//							e.printStackTrace();
//						}
//					}
					}
					
					
				}
				
			}
		} catch (ParserConfigurationException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (SAXException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		}
		
		
	}

	public void add(Packet msg) {
		synchronized (msgs_) {
			msgs_.add(msg);
			msgs_.notify();
		}
	}

	public void terminate() {
		synchronized (msgs_) {
			isRunning_ = false;
			msgs_.notify();
		}
	}
}
