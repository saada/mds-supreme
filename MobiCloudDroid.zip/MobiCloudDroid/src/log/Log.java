package log;

import java.util.Calendar;
import java.util.Date;

public class Log {
	public static Calendar CALENDAR = Calendar.getInstance();
	public static Date DATE = new Date();
	public static String userName;

	public static void setUserName(String name) {
		userName = name;
	}

	public static void i(String info) {
		System.out.println(userName + ":" + info);
	}

	public static void e(Exception e) {
		e.printStackTrace();
	}

	public static void e(String info) {
		System.out.println("Error: " + info);
	}
}
